#Oef 1
# install.packages("readxl")
library(readxl)
datajuni = read_excel("datajuni.xls")

temp = datajuni$TEMPERATUUR
qqnorm(temp); qqline(temp)
shapiro.test(temp)

mean_0 = 20
conf = 0.05
n = length(temp)

my_mean = mean(temp)
my_sd = sqrt(var(temp))
test_waarde = (my_mean - mean_0)/(my_sd/sqrt(n))
test_waarde

AG = c(qt(conf/2, n-1), qt(1-conf/2, n-1))
AG

p_waarde = 2*min(pt(test_waarde, n-1), pt(test_waarde, n-1, lower.tail = FALSE))
p_waarde

x = seq(-3,3,0.001)
y = dt(x,n-1)
plot(x,y, type="l")
polygon(c(x[x<=test_waarde], test_waarde), c(y[x<=test_waarde], min(y)), col="gray")
polygon(c(x[x>=-test_waarde], -test_waarde), c(y[x>=-test_waarde], min(y)), col="gray")
abline(v=test_waarde, col="blue")
abline(v=AG, col="red")
legend("topright",legend=c("p waarde", "Test waarde", "Aanvaardingsgebied"), fill=c("grey", "blue", "red"), )

#Oef 2
CO <- read.csv2("CO.csv")
emissie = CO$emissie
qqnorm(emissie); qqline(emissie)
shapiro.test(emissie)

log_emissie = log(emissie)
qqnorm(log_emissie); qqline(log_emissie)
shapiro.test(log_emissie)
t.test(log_emissie, mu=1)

#Oef 3
evenwicht = read_excel("evenwicht.xls")
oud = evenwicht$zwaai[evenwicht$leeftijd==1]
n = length(oud)
jong = evenwicht$zwaai[evenwicht$leeftijd==2]
m = length(jong)
shapiro.test(oud)
shapiro.test(jong)

conf = 0.05
# Gelijke varianties testen
test_waarde = var(oud)/var(jong)
test_waarde
AG = c(qf(conf/2,n-1,m-1), qf(conf/2,n-1,m-1,lower.tail = FALSE))
AG
p_waarde = 2*min(pf(test_waarde,n-1,m-1), pf(test_waarde,n-1,m-1,lower.tail = FALSE))
p_waarde

# Gelijke gemiddelde testen
gewogen_var = ((n-1)*var(oud) + (m-1)*var(jong))/(n + m -2)
test_waarde = (mean(oud) - mean(jong))/(sqrt(gewogen_var*(1/n + 1/m)))
test_waarde
AG = c(qt(conf/2,n+m-2), qt(conf/2,n+m-2,lower.tail = FALSE))
AG
p_waarde = 2*min(pt(test_waarde,n+m-2), pt(test_waarde,n+m-2,lower.tail = FALSE))
p_waarde

#Oef 4
cholesterol <- read.delim("cholesterol.txt")
dag2 = cholesterol$cholest2
dag4 = cholesterol$cholest4

verschil = dag2-dag4
qqnorm(verschil); qqline(verschil)
shapiro.test(verschil)
t.test(verschil, mu = 0, alternative = "greater")

#Oef 5
n1 = 167
p1 = 35/n1
n2 = 27
p2 = 6/n2

n1*p1>=5 & n1*(1-p1)>=5 & n2*p2>=5 & n2*(1-p2)>=5

conf = 0.05
p0 = (n1*p1+n2*p2)/(n1+n2)
test_waarde = (p1-p2)/sqrt(p0*(1-p0)*(1/n1+1/n2))
test_waarde
AG = c(qnorm(conf/2), qnorm(conf/2,lower.tail = FALSE))
AG
p_waarde = 2*min(pnorm(test_waarde), pnorm(test_waarde,lower.tail = FALSE))
p_waarde

#Oef6
data = c(1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1)
binom.test(sum(data), length(data), p = 0.5)

#Oef7


#Oef8
rivieren = read_excel("rivieren.xls")
stil = rivieren$lengte[rivieren$zee == 1]
n = length(stil)
tas = rivieren$lengte[rivieren$zee == 2]
m = length(tas)

qqnorm(stil); qqline(stil)
qqnorm(tas); qqline(tas)
shapiro.test(stil)
shapiro.test(tas)

conf = 0.05
# Gelijke varianties testen
test_waarde = var(stil)/var(tas)
test_waarde
AG = c(qf(conf/2,n-1,m-1), qf(conf/2,n-1,m-1,lower.tail = FALSE))
AG
p_waarde = 2*min(pf(test_waarde,n-1,m-1), pf(test_waarde,n-1,m-1,lower.tail = FALSE))
p_waarde

# Gelijke gemiddelde testen
test_waarde = (mean(stil) - mean(tas))/(sqrt(var(stil)/n + var(tas)/m))
test_waarde
r = (var(stil)/n + var(tas)/m)^2 / ((var(stil)/n)^2/(n-1) + (var(tas)/m)^2/(m-1))
AG = c(-Inf, qt(conf/2,r,lower.tail = FALSE))
AG
p_waarde = pt(test_waarde,r,lower.tail = FALSE)
p_waarde

#Extra visualization
par(mfrow=c(1,2))
x = seq(-7,7,0.001)
y = dt(x,r)

x2 = seq(5,7,0.001)
y2 = dt(x2,r)

plot(x,y, type="l")
polygon(c(x[x>test_waarde], test_waarde), c(y[x>test_waarde], min(y)), col="gray")
abline(v=test_waarde, col="blue")
abline(v=c(min(x)-0.4,AG[2]), col="red")
rect(xleft = min(x2), xright = max(x2), ybottom = -0.005, ytop = max(y2) + 0.005, border = "green")

plot(x2,y2, type="l")
polygon(c(x[x>test_waarde], test_waarde), c(y[x>test_waarde], min(y)), col="gray")
abline(v=test_waarde, col="blue")
abline(v=AG, col="red")
rect(xleft = min(x2)- 0.03, xright = max(x2)+0.03, ybottom = 0 - 5*10^-7, ytop = max(y2)+ 5*10^-7, border = "green")
legend("topright",legend=c("p waarde", "Test waarde", "Aanvaardingsgebied"), fill=c("grey", "blue", "red"), )
par(mfrow=c(1,1))
