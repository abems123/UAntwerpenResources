#Oef 1
haarogen <- rbind(c(326,38,241,110,3),c(688,116,584,188,4),
                  c(343,84,909,412,26),c(98,48,403,681,85))

chisq.test(haarogen)

n = dim(haarogen)[1]
m = dim(haarogen)[2]
k = (n-1)*(m-1)

col_sum = colSums(haarogen)
row_sum = rowSums(haarogen)
N = sum(haarogen)

expected_table = t(t(row_sum)) %*% col_sum / N
expected_table>5
test_waarde = sum((haarogen - expected_table)^2 / expected_table)
test_waarde
AG = c(0, qchisq(0.05, k, lower.tail = F))
AG
p_waarde = pchisq(test_waarde, k, lower.tail = F)
p_waarde

#Oef 2
library(readxl)
roken = read_xlsx('roken.xlsx')

#a
rokers = roken$rokers
mortal = roken$mortaliteit

plot(rokers, mortal)
rokers2 = rokers[-6]
mortal2 = mortal[-6]
plot(rokers2, mortal2)

#b
qqnorm(rokers2); qqline(rokers2)
shapiro.test(rokers2)
qqnorm(mortal2); qqline(mortal2)
shapiro.test(mortal2)

plot(mvrnorm(1000, mu=c(0,0), Sigma = rbind(c(1,-0.9), c(-0.9,1))))
#c
r = cor(rokers2, mortal2)
n = length(rokers2)
cor.test(rokers2, mortal2)

test_waarde = r/sqrt((1-r^2)/(n-2))
test_waarde
AG = c(qt(0.025, n-2), qt(0.025, n-2, lower.tail = F))
AG
p_waarde = 2*min(pt(test_waarde, n-2), pt(test_waarde, n-2, lower.tail = F))
p_waarde

#d
model = lm(mortal2 ~ rokers2)
summary(model)
model2 = lm(mortal2 ~ rokers2-1)
summary(model2)
qqnorm(model2$residuals); qqline(model2$residuals)
shapiro.test(model2$residuals)
plot(rokers2, model2$residuals)
plot(mortal2, model2$residuals)

#e
plot(rokers2, mortal2)
abline(a=0, b=model2$coefficients[1])

#Oef 3
Advertising <- read.csv("Advertising.csv", row.names = 1)
sales = Advertising$Sales
news = Advertising$Newspaper
tv = Advertising$TV
radio = Advertising$Radio
model = lm(Sales ~ ., data = Advertising)
summary(model)

reduced_model = lm(Sales ~ TV + Radio, data = Advertising)
summary(reduced_model)

qqnorm(reduced_model$residuals); qqline(reduced_model$residuals)
shapiro.test(reduced_model$residuals)
plot(tv, reduced_model$residuals)
plot(radio, reduced_model$residuals)

# Visualiseer model
par(mfrow = c(2,1))
plot(tv, sales)
abline(a=reduced_model$coefficients[1] + mean(radio)*reduced_model$coefficients[3], 
       b=reduced_model$coefficients[2])
plot(radio, sales)
abline(a=reduced_model$coefficients[1] + mean(tv)*reduced_model$coefficients[2], 
       b=reduced_model$coefficients[3])
par(mfrow = c(1,1))

#Oef 4
test_waarde = 0.38531/0.14622
test_waarde
p_waarde = 2*min(min(pt(test_waarde, 48), pt(test_waarde, 48, lower.tail = F)))
p_waarde

2.924 + 0.385 * 10

#Oef 5
sport <- rbind(c(34, 33, 7),c(22, 22, 4))

chisq.test(sport)

n = dim(sport)[1]
m = dim(sport)[2]
k = (n-1)*(m-1)

col_sum = colSums(sport)
row_sum = rowSums(sport)
N = sum(sport)

expected_table = t(t(row_sum)) %*% col_sum / N
expected_table>5
test_waarde = sum((sport - expected_table)^2 / expected_table)
test_waarde
AG = c(0, qchisq(0.05, k, lower.tail = F))
AG
p_waarde = pchisq(test_waarde, k, lower.tail = F)
p_waarde

#Oef 6
vis  = read_xls('vis.xls')

plot(vis$Prijs70, vis$Prijs80)
qqnorm(vis$Prijs70); qqline(vis$Prijs70)
qqnorm(vis$Prijs80); qqline(vis$Prijs80)

vis2 = vis[-13,]
p70 = vis2$Prijs70
p80 = vis2$Prijs80

model = lm(p70 ~ p80)
summary(model)

model2 = lm(p70 ~ p80 - 1)
summary(model2)

qqnorm(model2$residuals); qqline(model2$residuals)
shapiro.test(model2$residuals)

#Oef 7
sarah = rbind(c(36, 48, 51, 54, 57, 60), c(86, 90, 91, 93, 94, 95))
plot(sarah[1,], sarah[2,])

cor(sarah[1,], sarah[2,])

cor.test(sarah[1,], sarah[2,])
