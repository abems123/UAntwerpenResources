#Oef 1
resultaten = read.delim("resultaten.txt")
plot(resultaten$middelbaar, resultaten$bachelor)

lengte = resultaten$lengte
lengteV=lengte[resultaten$geslacht=="V"]
lengteM=lengte[resultaten$geslacht=="M"]
mean(lengteV)
mean(lengteM)
median(lengteV)
median(lengteM)
boxplot(lengte ~ geslacht, data = resultaten)

var(resultaten$lengte)
range(resultaten$lengte)
IQR(resultaten$lengte)

#Oef 2
pnorm(8, mean = 5, sd = 2)
dnorm(2.1, mean = 5, sd = 2)
pt(3.5, df = 6)
pchisq(1, df = 3, lower.tail = FALSE)
dbinom(20, size = 30, prob = 0.7)
factorial(30)/(factorial(20)*factorial(10)) * 0.7^20 * 0.3^10
qnorm(0.91)
qt(0.25, df = 67)
rf(83, df1 = 27, df2 = 15)
x = rnorm(50); mean(x); median(x); var(x)

#Oef 3
pnorm(120, mean = 110, sd = 20)
qnorm(0.90, mean = 110, sd = 20)

#Oef 4
pnorm(6.15, mean = 6, sd = 0.1) - pnorm(5.90, mean = 6, sd = 0.1)
pnorm(6.10, mean = 6, sd = 0.1, lower.tail = FALSE)
pnorm(5.95, mean = 6, sd = 0.1)
qnorm(0.95, mean = 6, sd = 0.1)

#Oef 5
x = c(13, 17, 15, 23, 27, 29, 18, 27, 20, 24)
my_mean = mean(x)
my_sd = sqrt(var(x))
n = length(x)

conf <- 0.05
quantile <- qt(1-conf/2, n-1)
upper_bound <- my_mean + quantile*my_sd/sqrt(n)
lower_bound <- my_mean - quantile*my_sd/sqrt(n)
# BI voor gemiddelde:
my_mean
my_sd
c(lower_bound, upper_bound)

#Oef 6
qqnorm(lengte); qqline(lengte)

qqnorm(lengteV); qqline(lengteV)
qqnorm(lengteM); qqline(lengteM)

shapiro.test(lengte)
shapiro.test(lengteV)
shapiro.test(lengteM)

#Oef 7
statdata1 = read.csv2("statdata1.csv")
data1 = statdata1$data1
statdata2 = read.csv2("statdata2.csv")
data2 = statdata2$data2
statdata3 = read.csv2("statdata3.csv")
data3 = statdata3$data3

qqnorm(data1); qqline(data1)
shapiro.test(data1)
log_data1 = log(data1)
qqnorm(log_data1); qqline(log_data1)
shapiro.test(log_data1)


qqnorm(data2); qqline(data2)
shapiro.test(data2)
range(data2)
log_data2 = log(data2 + 200)
qqnorm(log_data2); qqline(log_data2)
shapiro.test(log_data2)

qqnorm(data3); qqline(data3)
shapiro.test(data3)
hist(data3)
sqrt_data3 = sqrt(data3)
qqnorm(sqrt_data3); qqline(sqrt_data3)
shapiro.test(sqrt_data3)
#log_data3 = log(data3+400)
#qqnorm(log_data3); qqline(log_data3)
#shapiro.test(log_data3)

#Oef 8
x=seq(0,5,0.1)
y1=dexp(x,1)
y2=dexp(x,2)
y3=dexp(x,5)
y4=dexp(x,10)
plot(x,y1,type="l",xlab="x",ylab="f(x)",
     main="Dichtheidsfuncties van exponentiële verdeling",ylim=c(0,1),lwd=2)

lines(x,y2,col="red",lty=2,lwd=2)
lines(x,y3,col="blue",lty=3,lwd=2)
lines(x,y4,col="green",lty=4,lwd=2)
legend("topright",legend=paste("Exp(",c(1,2,5,10),")",sep=""),
       col=1:4,lty=1:4,lwd=2)

#Oef 9
m=100
n=100
conf=0.05
mean_list = rep(0,m)
upper_bound_list = rep(0,m)
lower_bound_list = rep(0,m)
for (i in 1:m){
  x = rnorm(n)
  my_mean = mean(x)
  my_sd = sqrt(var(x))
  
  quantile <- qt(1-conf/2, n-1)
  mean_list[i] = my_mean
  upper_bound_list[i] <- my_mean + quantile*my_sd/sqrt(n)
  lower_bound_list[i] <- my_mean - quantile*my_sd/sqrt(n)
}
sum(upper_bound_list<0) + sum(lower_bound_list>0)

# Extra visualisatie
library(latex2exp)
library(ggplot2)

df <- data.frame(
  id = 1:m,
  estimate = mean_list,
  lower = lower_bound_list,
  upper = upper_bound_list,
  contains_zero = (lower_bound_list <= 0 & upper_bound_list >= 0)
)

ggplot(df, aes(x = estimate, y = id)) +
  geom_vline(xintercept = 0, color = "black") +
  geom_errorbarh(aes(xmin = lower, xmax = upper, color = contains_zero), height = 0) +
  scale_color_manual(values = c("FALSE" = "red", "TRUE" = "gray70")) +
  geom_point(color = "gray40") +
  theme_minimal() +
  theme(
    axis.title.y = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    plot.title = element_text(hjust = 0.5),
    legend.position = "none"
  ) +
  labs(x = TeX("Schatting $\\hat{\\mu}$ en Betrouwbaarheidsinterval voor $\\mu$"), title = TeX("100 Betrouwbaarheidsintervallen voor $\\mu$ met $X \\sim N(0,1)$")) +
  coord_cartesian(xlim = c(-0.5, 0.5))







