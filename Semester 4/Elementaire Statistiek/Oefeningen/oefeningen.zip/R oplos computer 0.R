5+3
x <- 5+3
y = 9-2
x
x*y

z <- log(x)
?log
a <- sqrt(x)*z^2
b <- exp(a+z)
rm(x,y) #Removes x and y from environment
ls() #Shows environment
rm(list=ls()) #Clear the whole environment

Kleur = c("D","D","L","L","R","R")
Geslacht = c("M","V","M","V","M","V")
Aantal = c(9,14,12,11,3,7)
Dataset = data.frame(Kleur,Geslacht,Aantal)
Dataset

rm(list=ls())
resultaten <- read.delim("~/Documents/U Antwerpen/Elementaire Statistiek/Oefenzittingen /Computeroefenzitting 0/resultaten.txt")

lengte=resultaten$lengte
hist(lengte, main="Histogram van lengte studenten", xlab="lengte (in cm)",
     ylab= "absolute frequentie", ylim=c(0,20))

hist(lengte,main="Dichtheidshistogram van lengte studenten",
     xlab="lengte (in cm)", ylab= "relatieve frequentie", freq=FALSE)

lengteV=lengte[resultaten$geslacht=="V"]
lengteM=lengte[resultaten$geslacht=="M"]

mean(lengteV)
mean(lengteM)

median(lengteV)
median(lengteM)

hist(lengteV)
hist(lengteM)

sd(lengteV)
sd(lengteV)^2
var(lengteV)

IQR(lengteV)

mad(lengteV, constant = 1)

boxplot(lengteV)
boxplot(resultaten$lengte~resultaten$geslacht)

x=seq(-3,3,0.01)
y=dnorm(x)
plot(x,y,type="l",xlab="x",ylab=expression(phi(x)),
     main="Dichtheidsfunctie standaard normale verdeling")

x=seq(-4,4,0.01)
y1=pnorm(x)
y2=pnorm(x,0,sqrt(2))
plot(x,y1,type="l",xlab="x",ylab="F(x)",
     main = "Verdelingsfuncties normale verdelingen")
lines(x,y2,col="red",lty=3)
