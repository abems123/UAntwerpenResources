int main() {

char invalid = '';
}
