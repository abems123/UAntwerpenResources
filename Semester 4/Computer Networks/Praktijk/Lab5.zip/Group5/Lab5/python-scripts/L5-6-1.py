from ipmininet.iptopo import IPTopo
from ipmininet.ipnet import IPNet
from ipmininet.cli import IPCLI


class MyTopo(IPTopo):
    def build(self, *args, **kwargs):
        s1 = self.addSwitch("s1", stp=False)
        s2 = self.addSwitch("s2", stp=False)
        s3 = self.addSwitch("s3", stp=False)
        s4 = self.addSwitch("s4", stp=False)

        h1 = self.addHost("h1")
        h2 = self.addHost("h2")

        # Hosts
        self.addLink(h1, s1, params1={"ip": "fc00::1/64"}, bw=1)
        self.addLink(s2, h2, params2={"ip": "fc00::2/64"}, bw=1)

        # Switch loop
        self.addLink(s1, s3, bw=1)
        self.addLink(s3, s2, bw=1)
        self.addLink(s2, s4, bw=1)
        self.addLink(s4, s1, bw=1)

        super().build(*args, **kwargs)


net = IPNet(topo=MyTopo(), allocate_IPs=False)

try:
    net.start()
    IPCLI(net)
finally:
    net.stop()