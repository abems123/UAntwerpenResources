from ipmininet.iptopo import IPTopo
from ipmininet.ipnet import IPNet
from ipmininet.cli import IPCLI


class MyTopo(IPTopo):
    def build(self, *args, **kwargs):
        h1 = self.addHost("h1")
        h2 = self.addHost("h2")
        h3 = self.addHost("h3")

        self.addLink(h1, h2, params1={"ip": "fc00::1/64"})
        self.addLink(h2, h3, params2={"ip": "fc00::3/64"})

        super().build(*args, **kwargs)


net = IPNet(topo=MyTopo(), allocate_IPs=False)

try:
    net.start()
    IPCLI(net)
finally:
    net.stop()