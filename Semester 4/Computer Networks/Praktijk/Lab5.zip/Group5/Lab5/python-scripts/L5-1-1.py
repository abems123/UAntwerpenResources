from ipmininet.iptopo import IPTopo
from ipmininet.ipnet import IPNet
from ipmininet.cli import IPCLI

class MyTopo(IPTopo):
    def build(self, *args, **kwargs):
        # Add switch
        s1 = self.addSwitch("s1", stp=False)

        # Add hosts
        h1 = self.addHost("h1")
        h2 = self.addHost("h2")
        h3 = self.addHost("h3")
        h4 = self.addHost("h4")

        # Connect all hosts to the switch and assign IPv6 addresses
        self.addLink(s1, h1, params2={"ip": "fc00::1/64"})
        self.addLink(s1, h2, params2={"ip": "fc00::2/64"})
        self.addLink(s1, h3, params2={"ip": "fc00::3/64"})
        self.addLink(s1, h4, params2={"ip": "fc00::4/64"})

        super().build(*args, **kwargs)

net = IPNet(topo=MyTopo(), allocate_IPs=False)
try:
    net.start()
    IPCLI(net)
finally:
    net.stop()
