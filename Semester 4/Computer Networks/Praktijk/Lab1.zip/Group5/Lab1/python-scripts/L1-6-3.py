import socket

host = "www.uantwerpen.be"
path = "/"
port = 80

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((host, port))

request = (
    f"GET {path} HTTP/1.1\r\n"
    f"Host: {host}\r\n"
    "Connection: close\r\n"
    "\r\n"
)
request_in_bytes = request.encode()
client.sendall(request_in_bytes)

response = b""
while True:
    chunk = client.recv(4096)
    if not chunk:
        break
    response += chunk

print(response.decode(errors="ignore"))

client.close()