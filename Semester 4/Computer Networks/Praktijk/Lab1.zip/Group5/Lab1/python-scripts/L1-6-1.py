import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("www.google.be", 80))

request = 'GET / HTTP/1.1 \r\nHost: www.google.be\r\nConnection: close\r\n\r\n'
request_in_bytes = request.encode()
client.sendall(request_in_bytes)