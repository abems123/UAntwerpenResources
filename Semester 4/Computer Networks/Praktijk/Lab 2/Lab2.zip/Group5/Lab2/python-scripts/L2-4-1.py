from ipmininet.iptopo import IPTopo
from ipmininet.ipnet import IPNet
from ipmininet.cli import IPCLI

class MyTopo(IPTopo):

    def build(self, *args, **kwargs):

        h1 = self.addHost("h1")
        h2 = self.addHost("h2")

        r1 = self.addRouter("r1")

        # h1 -- r1 (eth0 van r1)
        lh1r1 = self.addLink(h1, r1, bw=1)
        lh1r1[h1].addParams(ip=("fc00:0:0:1::1/64"))
        lh1r1[r1].addParams(ip=("fc00:0:0:1::10/64"))

        # h2 -- r1 (eth1 van r1)
        lh2r1 = self.addLink(h2, r1, bw=1)
        lh2r1[h2].addParams(ip=("fc00:0:0:2::2/64"))
        lh2r1[r1].addParams(ip=("fc00:0:0:2::10/64"))

        super().build(*args, **kwargs)

net = IPNet(topo=MyTopo(), allocate_IPs=False)

try:
    net.start()
    IPCLI(net)
finally:
    net.stop()
