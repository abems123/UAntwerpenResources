from ipmininet.iptopo import IPTopo
from ipmininet.ipnet import IPNet
from ipmininet.cli import IPCLI


class MyTopo(IPTopo):
    def build(self, *args, **kwargs):
        h1 = self.addHost("h1")
        h2 = self.addHost("h2")
        h3 = self.addHost("h3")
        h4 = self.addHost("h4")
        r1 = self.addRouter("r1")

        # h1 -- r1
        l1 = self.addLink(h1, r1)
        l1[h1].addParams(ip="fc00:0:0:1::1/64")
        l1[r1].addParams(ip="fc00:0:0:1::10/64")

        # h2 -- r1
        l2 = self.addLink(h2, r1)
        l2[h2].addParams(ip="fc00:0:0:2::2/64")
        l2[r1].addParams(ip="fc00:0:0:2::10/64")

        # h3 -- r1
        l3 = self.addLink(h3, r1)
        l3[h3].addParams(ip="fc00:0:0:3::3/64")
        l3[r1].addParams(ip="fc00:0:0:3::10/64")

        # r1 -- h4 : bottleneck link
        l4 = self.addLink(r1, h4, bw=6, enable_red=True)
        l4[r1].addParams(ip="fc00:0:0:4::10/64")
        l4[h4].addParams(ip="fc00:0:0:4::4/64")

        super().build(*args, **kwargs)


net = IPNet(topo=MyTopo(), allocate_IPs=False)

try:
    net.start()

    # Disable TSO on the TCP senders
    net["h1"].cmd("ethtool -K h1-eth0 tso off")
    net["h2"].cmd("ethtool -K h2-eth0 tso off")

    IPCLI(net)
finally:
    net.stop()