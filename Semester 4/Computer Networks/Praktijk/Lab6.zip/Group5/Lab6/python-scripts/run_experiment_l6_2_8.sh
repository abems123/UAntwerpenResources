#!/bin/bash
set -e

rm -f aloha-intensity-*.dat throughput-l6-2-8.png

# These intervals are in microseconds.
# They are chosen so that the normalized load is comparable to L6-2-5/L6-2-7.
intervals=(1000000 90909 47619 32258 24390 19608 16393 14085 12346 10989)

for run in $(seq 1 5); do
  for interval in "${intervals[@]}"; do
    ./../../ns3 run --no-build --cwd=$PWD "aloha_vs_dcf --RngRun=$run --numOfStations=10 --interval=${interval}us --isDcf=false --collectPcap=false"

    throughput=$(awk '{print $2}' result.txt)
    echo "$interval $throughput" >> aloha-intensity-$run.dat
  done
done