#!/usr/bin/python3

import numpy as np
import matplotlib.pyplot as plt

num_runs = 5
tau_us = 1444
packet_bits = 8000
default_interval_us = 100000

# Previous experiment: fixed traffic intensity, varying number of stations
pure = np.zeros(10)

for run in range(1, num_runs + 1):
    df = np.genfromtxt(f"aloha-pure-{run}.dat", names=None)
    pure += df[:, 1] / num_runs

num_stas = np.array(range(1, 101, 10))
G_stations = num_stas * tau_us / default_interval_us
T_stations = pure * tau_us / packet_bits

# New experiment: fixed number of stations, varying traffic intensity
intensity = np.zeros(10)
intervals = None

for run in range(1, num_runs + 1):
    df = np.genfromtxt(f"aloha-intensity-{run}.dat", names=None)
    if intervals is None:
        intervals = df[:, 0]
    intensity += df[:, 1] / num_runs

G_intensity = 10 * tau_us / intervals
T_intensity = intensity * tau_us / packet_bits

idx = np.argsort(G_intensity)
G_intensity = G_intensity[idx]
T_intensity = T_intensity[idx]

plt.figure(figsize=[5.5, 4.0])

plt.plot(G_stations, T_stations, label="vary number of stations", marker="+", linestyle="None")
plt.plot(G_intensity, T_intensity, label="vary traffic intensity", marker="x", linestyle="None")

plt.xlabel("Normalized load G")
plt.ylabel("Normalized throughput T")
plt.grid()
plt.legend(loc="best")

plt.savefig("throughput-l6-2-8.png", dpi=200)

i = np.argmax(T_intensity)
print("max fixed-stations throughput =", T_intensity[i])
print("at G =", G_intensity[i])