#!/usr/bin/python3

import numpy as np
import matplotlib.pyplot as plt

num_runs = 5
max_stas = 100

tau_us = 1444
packet_interval_us = 100000
packet_bits = 8000

slotted = np.zeros(10)

for run in range(1, num_runs + 1):
    df = np.genfromtxt(f"aloha-slotted-{run}.dat", names=None)
    slotted += df[:, 1] / num_runs

num_stas = np.array(range(1, max_stas + 1, 10))

G_sim = num_stas * tau_us / packet_interval_us
T_sim = slotted * tau_us / packet_bits

G_theory = np.linspace(0, max(G_sim), 200)
T_theory = G_theory * np.exp(-G_theory)

plt.figure(figsize=[5.5, 4.0])

plt.plot(G_sim, T_sim, label="simulation slotted Aloha", marker="+", linestyle="None")
plt.plot(G_theory, T_theory, label="theory slotted Aloha")

plt.xlabel("Normalized load G")
plt.ylabel("Normalized throughput T")
plt.grid()
plt.legend(loc="best")

plt.savefig("throughput-slotted.png", dpi=200)

i = np.argmax(T_sim)
print("max normalized throughput =", T_sim[i])
print("at G =", G_sim[i])
print("number of stations =", num_stas[i])
