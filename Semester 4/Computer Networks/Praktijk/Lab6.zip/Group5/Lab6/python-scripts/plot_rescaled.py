#!/usr/bin/python3

import numpy as np
import matplotlib.pyplot as plt

num_runs = 5
max_stas = 100

# Values from the experiment/lab
tau_us = 1444          # packet transmission time from L6-2-3, in microseconds
packet_interval_us = 100000  # average inter-packet interval, in microseconds
packet_bits = 1000 * 8       # application payload size: 1000 bytes

pure = np.zeros(10)

for run in range(1, num_runs + 1):
    df_pure = np.genfromtxt(f"aloha-pure-{run}.dat", names=None)
    pure += df_pure[:, 1] / num_runs

num_stas = np.array(range(1, max_stas + 1, 10))

# Rescale x-axis: number of stations -> normalized load
G_sim = num_stas * tau_us / packet_interval_us

# Rescale y-axis: Mbps -> normalized throughput
T_sim = pure * tau_us / packet_bits

# Analytical pure Aloha curve
G_theory = np.linspace(0, max(G_sim), 200)
T_theory = G_theory * np.exp(-2 * G_theory)

plt.figure(figsize=[5.5, 4.0])

plt.plot(G_sim, T_sim, label="simulation pure Aloha", marker="+", linestyle="None")
plt.plot(G_theory, T_theory, label="theory pure Aloha")

plt.xlabel("Normalized load G")
plt.ylabel("Normalized throughput T")
plt.grid()
plt.legend(loc="best")

plt.savefig("throughput-normalized.png", dpi=200)