# Exercise Corrections Hub

This version is made around the workflow you described:

- a **simple, clean, beautiful** website
- a **leaderboard** of who solved the most exercises
- an **exercise library** where users can open corrections
- every correction can be viewed as **LaTeX source** and as **PDF**
- you can upload a **new ZIP** every time the exercise collection changes
- access is gated by **GitHub login** and your approval list can be handled through a GitHub organization or team

## What changed in this version

Compared with the first version, this one now includes:

- a dedicated **Exercise library** section
- an **exercise modal** with two views:
  - **LaTeX source**
  - **PDF preview**
- a cleaner and lighter design
- a better publish model:
  - the site publishes a **manifest JSON**
  - the site publishes the **latest source ZIP**
  - the **private data repo** can auto-build all PDFs from that ZIP

This is the key idea:

1. You upload the latest ZIP.
2. The website parses it and previews the new leaderboard immediately.
3. You publish it to your private data repo.
4. A workflow in that private repo generates the PDFs.
5. Logged-in approved users can browse the corrections as both `.tex` and `.pdf`.

---

## Project files

- `index.html` — main page
- `styles.css` — visual design
- `app.js` — parsing, auth, UI, publish logic
- `config.js` — active config for local testing
- `config.example.js` — template for real deployment
- `worker/github-token-exchange.js` — optional Worker for OAuth token exchange
- `private-data-repo-template/` — starter template for the private repo that stores the manifest, ZIP, and PDFs

---

## Recommended setup

Use **two repositories**:

### 1. Public GitHub Pages repo

This repo contains the website code only.

Example:

- `exercise-corrections-site`

### 2. Private data repo

This repo contains the current exercise data and the generated PDFs.

Example:

- `exercise-corrections-data`

The site expects this structure inside the private repo:

```text
data/
  manifest.json
  build-status.json
  sources/
    latest-exercises.zip
  pdfs/
    1A-4.1-elaine.de.bie.INF.pdf
    ...
```

---

## Access control idea

The website is meant to work like this:

- users open the GitHub Pages site
- they sign in with GitHub
- the site checks whether they are in your **GitHub organization**
- optionally, it can also require a specific **GitHub team**
- only approved users can load the private exercise data

For your own approval flow, the cleanest setup is:

- create a GitHub organization for this project
- invite only the people you accept
- optionally put the approved viewers in one team and set `GITHUB_TEAM_SLUG`

The admin upload panel is shown only for logins listed in `ADMIN_LOGINS`.

---

## Local testing first

For local testing, keep this in `config.js`:

```js
AUTH_ENABLED: false
```

That gives you a local preview mode where you can:

- open the site
- upload a ZIP
- preview the leaderboard
- browse the exercise library
- open LaTeX source immediately

PDF preview in local mode is not the main target, because PDFs are meant to come from the private repo after publish.

---

## Real deployment steps

### Step 1: configure the site repo

Copy `config.example.js` to `config.js` and fill in your values.

Main fields:

```js
window.APP_CONFIG = {
  APP_TITLE: "Exercise Corrections Hub",
  AUTH_ENABLED: true,
  GITHUB_CLIENT_ID: "YOUR_GITHUB_CLIENT_ID",
  GITHUB_ORG_SLUG: "your-organization",
  GITHUB_TEAM_SLUG: "",
  TOKEN_EXCHANGE_URL: "",
  DATA_REPO_OWNER: "your-organization",
  DATA_REPO_NAME: "exercise-corrections-data",
  DATA_BRANCH: "main",
  MANIFEST_PATH: "data/manifest.json",
  SOURCES_ZIP_PATH: "data/sources/latest-exercises.zip",
  PDF_DIR: "data/pdfs",
  BUILD_STATUS_PATH: "data/build-status.json",
  ADMIN_LOGINS: ["your-github-login"],
};
```

### Step 2: prepare the private data repo

Copy the contents of `private-data-repo-template/` into your private repo.

That repo includes a workflow that:

- watches for changes to `data/sources/latest-exercises.zip`
- unzips the source files
- compiles all `.tex` files into PDFs
- writes `data/build-status.json`
- commits the generated PDFs back into the private repo

### Step 3: deploy the public site to GitHub Pages

Push the website files to your public repository and enable GitHub Pages for that repo.

### Step 4: sign in as admin and publish

Once the site is live:

1. sign in with GitHub
2. upload the latest ZIP
3. click **Preview upload**
4. check the leaderboard and exercise library
5. click **Publish to private repo**

After that, the private repo workflow should build the PDFs.

---

## Expected file naming

The parser expects filenames like:

```text
1B-14.20-anass.hamzaoui.INF.tex
```

It extracts:

- section: `1B`
- exercise number: `14.20`
- exercise ID: `1B-14.20`
- person: `Anass Hamzaoui`

So the leaderboard is built straight from the filenames.

---

## Notes about the PDF workflow

This project assumes the uploaded `.tex` files are real standalone LaTeX documents.

That matches the ZIP you uploaded here: the files include `\documentclass`, packages, and `\begin{document}` / `\end{document}`.

That is why the private repo can compile them automatically into PDFs.

If later you upload files that are only fragments and not full LaTeX documents, you would need to wrap them before compilation.

---

## Good practical workflow for you

The easiest day-to-day flow is this:

- keep the public site unchanged most of the time
- when the exercise list changes, open the site
- upload the new ZIP
- preview it
- publish it
- let the private repo regenerate the PDFs

That means you do **not** need to manually edit hundreds of files every time.

---

## One useful detail

This site is intentionally designed so the **public GitHub Pages repo** stores the interface, while the **private data repo** stores the real exercise data.

That keeps the public site clean while still letting approved users open the protected content after login.
