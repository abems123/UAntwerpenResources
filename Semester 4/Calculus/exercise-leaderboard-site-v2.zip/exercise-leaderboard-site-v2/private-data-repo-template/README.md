# Private data repo template

Put these files into your **private** GitHub repository.

This repo is where the website will publish:

- `data/manifest.json`
- `data/sources/latest-exercises.zip`

The workflow in `.github/workflows/build-pdfs.yml` then generates:

- `data/pdfs/*.pdf`
- `data/build-status.json`

## Why this repo is separate

The website itself can stay on a public GitHub Pages repo.

The real exercise data stays here in a private repo, which is what the logged-in users will read.

## First-time setup

1. Create a private repo, for example `exercise-corrections-data`.
2. Copy this whole template into it.
3. Push it.
4. Point the public site config to this repo.
5. Publish your first ZIP from the website admin panel.

## What the workflow does

When `data/sources/latest-exercises.zip` changes, the workflow:

1. unzips the source files
2. compiles every `.tex` file it can
3. stores the PDFs in `data/pdfs/`
4. stores a build report in `data/build-status.json`
5. commits the result back into the private repo
