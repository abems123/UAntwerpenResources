window.APP_CONFIG = {
  APP_TITLE: "Exercise Corrections Hub",

  // Turn this on for the real GitHub Pages deployment.
  AUTH_ENABLED: true,

  // GitHub OAuth / GitHub App settings.
  GITHUB_CLIENT_ID: "YOUR_GITHUB_CLIENT_ID",
  GITHUB_ORG_SLUG: "your-organization",

  // Optional: restrict access even further to one specific team.
  GITHUB_TEAM_SLUG: "",

  // Optional Worker URL for exchanging the OAuth code for a token.
  // Leave empty only if your GitHub setup supports your chosen direct flow.
  TOKEN_EXCHANGE_URL: "",

  // Private data repo where the site reads the manifest, the ZIP, and the PDFs.
  DATA_REPO_OWNER: "your-organization",
  DATA_REPO_NAME: "exercise-corrections-data",
  DATA_BRANCH: "main",
  MANIFEST_PATH: "data/manifest.json",
  SOURCES_ZIP_PATH: "data/sources/latest-exercises.zip",
  PDF_DIR: "data/pdfs",
  BUILD_STATUS_PATH: "data/build-status.json",

  // Only these GitHub logins can see the admin upload/publish panel.
  ADMIN_LOGINS: ["your-github-login"],
};
