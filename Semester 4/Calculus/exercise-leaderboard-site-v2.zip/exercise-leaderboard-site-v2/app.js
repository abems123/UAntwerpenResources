const CONFIG = window.APP_CONFIG || {};

const DEFAULTS = {
  APP_TITLE: "Exercise Corrections Hub",
  AUTH_ENABLED: false,
  GITHUB_CLIENT_ID: "",
  GITHUB_ORG_SLUG: "",
  GITHUB_TEAM_SLUG: "",
  TOKEN_EXCHANGE_URL: "",
  DATA_REPO_OWNER: "",
  DATA_REPO_NAME: "",
  DATA_BRANCH: "main",
  MANIFEST_PATH: "data/manifest.json",
  SOURCES_ZIP_PATH: "data/sources/latest-exercises.zip",
  PDF_DIR: "data/pdfs",
  BUILD_STATUS_PATH: "data/build-status.json",
  ADMIN_LOGINS: [],
};

const cfg = { ...DEFAULTS, ...CONFIG };

const state = {
  token: null,
  currentUser: null,
  accessGranted: false,
  isAdmin: false,
  selectedPerson: null,
  publishedData: null,
  workingData: null,
  workingZipName: "",
  workingZipBytes: null,
  sourceCache: new Map(),
  sourceZipLoaded: false,
  pdfUrlCache: new Map(),
  buildStatus: null,
  lastModalExercise: null,
};

const els = {
  appTitle: document.getElementById("appTitle"),
  loginButton: document.getElementById("loginButton"),
  logoutButton: document.getElementById("logoutButton"),
  statusText: document.getElementById("statusText"),
  statusBadge: document.getElementById("statusBadge"),
  appContent: document.getElementById("appContent"),
  totalExercises: document.getElementById("totalExercises"),
  uniquePeople: document.getElementById("uniquePeople"),
  currentLeader: document.getElementById("currentLeader"),
  lastPublished: document.getElementById("lastPublished"),
  leaderboardSearch: document.getElementById("leaderboardSearch"),
  sortSelect: document.getElementById("sortSelect"),
  leaderboardBody: document.getElementById("leaderboardBody"),
  podium: document.getElementById("podium"),
  personCardTitle: document.getElementById("personCardTitle"),
  personCardSubtitle: document.getElementById("personCardSubtitle"),
  personSections: document.getElementById("personSections"),
  visibleExercisesCount: document.getElementById("visibleExercisesCount"),
  visibleSectionsCount: document.getElementById("visibleSectionsCount"),
  clearPersonFilterButton: document.getElementById("clearPersonFilterButton"),
  exerciseSearch: document.getElementById("exerciseSearch"),
  sectionFilter: document.getElementById("sectionFilter"),
  exerciseGrid: document.getElementById("exerciseGrid"),
  datasetBanner: document.getElementById("datasetBanner"),
  adminPanel: document.getElementById("adminPanel"),
  zipInput: document.getElementById("zipInput"),
  previewButton: document.getElementById("previewButton"),
  publishButton: document.getElementById("publishButton"),
  downloadManifestButton: document.getElementById("downloadManifestButton"),
  adminLog: document.getElementById("adminLog"),
  exerciseModal: document.getElementById("exerciseModal"),
  closeModalButton: document.getElementById("closeModalButton"),
  modalEyebrow: document.getElementById("modalEyebrow"),
  modalTitle: document.getElementById("modalTitle"),
  modalSubtitle: document.getElementById("modalSubtitle"),
  modalMeta: document.getElementById("modalMeta"),
  openLatexTabButton: document.getElementById("openLatexTabButton"),
  openPdfTabButton: document.getElementById("openPdfTabButton"),
  downloadTexButton: document.getElementById("downloadTexButton"),
  downloadPdfButton: document.getElementById("downloadPdfButton"),
  latexTab: document.getElementById("latexTab"),
  pdfTab: document.getElementById("pdfTab"),
  latexPane: document.getElementById("latexPane"),
  pdfPane: document.getElementById("pdfPane"),
  latexContent: document.getElementById("latexContent"),
  pdfFallback: document.getElementById("pdfFallback"),
  pdfFrame: document.getElementById("pdfFrame"),
};

function setStatus(message, tone = "muted") {
  els.statusText.textContent = message;
  els.statusBadge.className = `badge badge-${tone}`;
  els.statusBadge.textContent = {
    success: "Access granted",
    warning: "Attention",
    danger: "Blocked",
    muted: "Info",
  }[tone] || "Info";
}

function logAdmin(message) {
  const stamp = new Date().toLocaleTimeString();
  const current = els.adminLog.textContent.trim();
  const row = `[${stamp}] ${message}`;
  els.adminLog.textContent = current === "No upload processed yet." ? row : `${current}\n${row}`;
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString();
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function encodeBase64Bytes(uint8) {
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < uint8.length; i += chunkSize) {
    binary += String.fromCharCode(...uint8.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function decodeBase64Utf8(text) {
  const binary = atob(text.replace(/\n/g, ""));
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function safeSlug(fileName) {
  return fileName
    .replace(/\.tex$/i, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function titleCaseWord(part) {
  if (!part) return part;
  return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
}

function normalizePerson(rawPerson) {
  return rawPerson
    .replace(/\.?(INF|WIS|TEW|TI|FYS|CHEM)$/i, "")
    .replace(/[._-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .map(titleCaseWord)
    .join(" ");
}

function parseTexFilename(entryName) {
  const fileName = entryName.split("/").pop();
  if (!fileName || !fileName.toLowerCase().endsWith(".tex")) return null;

  const base = fileName.replace(/\.tex$/i, "");
  const firstDash = base.indexOf("-");
  const secondDash = base.indexOf("-", firstDash + 1);

  if (firstDash === -1 || secondDash === -1) return null;

  const section = base.slice(0, firstDash).trim();
  const exerciseNumber = base.slice(firstDash + 1, secondDash).trim();
  const rawPerson = base.slice(secondDash + 1).trim();
  const person = normalizePerson(rawPerson);
  if (!section || !exerciseNumber || !person) return null;

  return {
    slug: safeSlug(fileName),
    entryName,
    fileName,
    section,
    exerciseNumber,
    exerciseId: `${section}-${exerciseNumber}`,
    person,
  };
}

function sortExercises(items) {
  return items.slice().sort((a, b) => {
    const bySection = a.section.localeCompare(b.section, undefined, { numeric: true });
    if (bySection !== 0) return bySection;
    const byNumber = a.exerciseNumber.localeCompare(b.exerciseNumber, undefined, { numeric: true });
    if (byNumber !== 0) return byNumber;
    return a.person.localeCompare(b.person);
  });
}

function buildManifest(entries, sourceLabel, zipFileName = "latest-exercises.zip") {
  const exercises = sortExercises(entries).map((entry) => ({
    slug: entry.slug,
    entryName: entry.entryName,
    fileName: entry.fileName,
    section: entry.section,
    exerciseNumber: entry.exerciseNumber,
    exerciseId: entry.exerciseId,
    person: entry.person,
    pdfPath: `${cfg.PDF_DIR}/${entry.slug}.pdf`,
  }));

  const grouped = new Map();
  for (const exercise of exercises) {
    if (!grouped.has(exercise.person)) grouped.set(exercise.person, []);
    grouped.get(exercise.person).push(exercise);
  }

  const leaderboard = Array.from(grouped.entries())
    .map(([name, items]) => {
      const sectionCounts = Array.from(items.reduce((map, item) => {
        map.set(item.section, (map.get(item.section) || 0) + 1);
        return map;
      }, new Map()).entries())
        .sort((a, b) => a[0].localeCompare(b[0], undefined, { numeric: true }))
        .map(([section, count]) => ({ section, count }));

      return {
        name,
        count: items.length,
        sectionCounts,
        exercises: items.map((item) => ({
          slug: item.slug,
          exerciseId: item.exerciseId,
          fileName: item.fileName,
          section: item.section,
          exerciseNumber: item.exerciseNumber,
          pdfPath: item.pdfPath,
        })),
      };
    })
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));

  return {
    generatedAt: new Date().toISOString(),
    sourceLabel,
    zipFileName,
    summary: {
      totalExercises: exercises.length,
      uniquePeople: leaderboard.length,
      leader: leaderboard[0]?.name || null,
      leaderCount: leaderboard[0]?.count || 0,
      sections: Array.from(new Set(exercises.map((item) => item.section))).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
    },
    leaderboard,
    exercises,
  };
}

function getActiveData() {
  return state.workingData || state.publishedData || {
    generatedAt: null,
    sourceLabel: "No dataset",
    summary: { totalExercises: 0, uniquePeople: 0, leader: null, leaderCount: 0, sections: [] },
    leaderboard: [],
    exercises: [],
  };
}

function getSelectedPersonRecord() {
  const data = getActiveData();
  return data.leaderboard.find((item) => item.name === state.selectedPerson) || null;
}

function getFilteredLeaderboard() {
  const data = getActiveData();
  const query = (els.leaderboardSearch.value || "").trim().toLowerCase();
  const sortMode = els.sortSelect.value;
  const filtered = data.leaderboard.filter((item) => item.name.toLowerCase().includes(query));

  filtered.sort((a, b) => {
    switch (sortMode) {
      case "count-asc":
        return a.count - b.count || a.name.localeCompare(b.name);
      case "name-asc":
        return a.name.localeCompare(b.name);
      case "name-desc":
        return b.name.localeCompare(a.name);
      default:
        return b.count - a.count || a.name.localeCompare(b.name);
    }
  });

  return filtered;
}

function getFilteredExercises() {
  const data = getActiveData();
  const query = (els.exerciseSearch.value || "").trim().toLowerCase();
  const section = els.sectionFilter.value || "";
  return data.exercises.filter((item) => {
    if (state.selectedPerson && item.person !== state.selectedPerson) return false;
    if (section && item.section !== section) return false;
    if (!query) return true;
    return [item.exerciseId, item.person, item.fileName, item.section]
      .some((value) => String(value).toLowerCase().includes(query));
  });
}

function renderStats() {
  const data = getActiveData();
  els.totalExercises.textContent = String(data.summary.totalExercises || 0);
  els.uniquePeople.textContent = String(data.summary.uniquePeople || 0);
  els.currentLeader.textContent = data.summary.leader
    ? `${data.summary.leader} (${data.summary.leaderCount})`
    : "—";
  els.lastPublished.textContent = formatDate(data.generatedAt);
}

function renderPodium(items) {
  if (!items.length) {
    els.podium.innerHTML = "";
    return;
  }

  const top = items.slice(0, 3);
  els.podium.innerHTML = top.map((item, index) => `
    <article class="podium-card">
      <div class="podium-rank">Top ${index + 1}</div>
      <strong>${escapeHtml(item.name)}</strong>
      <span>${item.count} exercise${item.count === 1 ? "" : "s"}</span>
    </article>
  `).join("");
}

function renderLeaderboard() {
  const items = getFilteredLeaderboard();
  renderPodium(items);

  if (!items.length) {
    els.leaderboardBody.innerHTML = '<tr><td colspan="3" class="table-empty-cell empty-state">No matching people found.</td></tr>';
    return;
  }

  els.leaderboardBody.innerHTML = items.map((item, index) => `
    <tr>
      <td colspan="3">
        <button class="table-button ${state.selectedPerson === item.name ? "active" : ""}" data-person="${escapeHtml(item.name)}">
          <span class="table-rank">${index + 1}</span>
          <span class="table-name">${escapeHtml(item.name)}</span>
          <span class="table-count">${item.count}</span>
        </button>
      </td>
    </tr>
  `).join("");

  els.leaderboardBody.querySelectorAll("[data-person]").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedPerson = button.getAttribute("data-person");
      renderAll();
    });
  });
}

function renderPersonSummary() {
  const personRecord = getSelectedPersonRecord();
  const visibleExercises = getFilteredExercises();
  const visibleSections = new Set(visibleExercises.map((item) => item.section));

  els.visibleExercisesCount.textContent = String(visibleExercises.length);
  els.visibleSectionsCount.textContent = String(visibleSections.size);

  if (!personRecord) {
    els.personCardTitle.textContent = "Exercise focus";
    els.personCardSubtitle.textContent = "Choose a person from the leaderboard, or browse everything below.";
    els.personSections.className = "section-chip-list empty-state-block";
    els.personSections.textContent = "No person selected.";
    els.clearPersonFilterButton.classList.add("hidden");
    return;
  }

  els.personCardTitle.textContent = personRecord.name;
  els.personCardSubtitle.textContent = `${personRecord.count} exercise${personRecord.count === 1 ? "" : "s"} in total.`;
  els.personSections.className = "section-chip-list";
  els.personSections.innerHTML = personRecord.sectionCounts.map((row) => `
    <span class="section-chip">${escapeHtml(row.section)} <strong>${row.count}</strong></span>
  `).join("");
  els.clearPersonFilterButton.classList.remove("hidden");
}

function renderSectionFilter() {
  const data = getActiveData();
  const current = els.sectionFilter.value;
  const sections = data.summary.sections || [];
  els.sectionFilter.innerHTML = '<option value="">All sections</option>' + sections
    .map((section) => `<option value="${escapeHtml(section)}">${escapeHtml(section)}</option>`)
    .join("");
  if (sections.includes(current)) {
    els.sectionFilter.value = current;
  }
}

function renderDatasetBanner() {
  const source = state.workingData ? "Previewing uploaded data" : state.publishedData ? "Showing published private data" : "No published data yet";
  const detail = getActiveData().generatedAt ? `Updated ${formatDate(getActiveData().generatedAt)}.` : "Upload a ZIP to start.";
  els.datasetBanner.textContent = `${source}. ${detail}`;
  els.datasetBanner.classList.remove("hidden");
}

function renderExercises() {
  const items = getFilteredExercises();
  if (!items.length) {
    els.exerciseGrid.innerHTML = `
      <article class="exercise-card empty-card">
        <p>No exercises match the current filters.</p>
      </article>
    `;
    return;
  }

  els.exerciseGrid.innerHTML = items.map((item) => `
    <article class="exercise-card">
      <div>
        <div class="exercise-meta">
          <span class="meta-pill">${escapeHtml(item.section)}</span>
          <span class="meta-pill">${escapeHtml(item.exerciseId)}</span>
        </div>
      </div>
      <div>
        <h3>${escapeHtml(item.fileName)}</h3>
        <p class="exercise-person">${escapeHtml(item.person)}</p>
      </div>
      <footer>
        <span class="exercise-person">LaTeX + PDF</span>
        <button class="button secondary" data-open-exercise="${escapeHtml(item.slug)}">Open</button>
      </footer>
    </article>
  `).join("");

  els.exerciseGrid.querySelectorAll("[data-open-exercise]").forEach((button) => {
    button.addEventListener("click", () => openExercise(button.getAttribute("data-open-exercise")));
  });
}

function renderAdminPanel() {
  if (!state.isAdmin) {
    els.adminPanel.classList.add("hidden");
    return;
  }
  els.adminPanel.classList.remove("hidden");
}

function renderAll() {
  const data = getActiveData();
  const selectedStillExists = !state.selectedPerson || data.leaderboard.some((item) => item.name === state.selectedPerson);
  if (!selectedStillExists) state.selectedPerson = null;

  renderStats();
  renderSectionFilter();
  renderLeaderboard();
  renderPersonSummary();
  renderExercises();
  renderDatasetBanner();
  renderAdminPanel();
}

function readStoredToken() {
  try {
    const raw = localStorage.getItem("exerciseLeaderboardToken");
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.token || null;
  } catch {
    return null;
  }
}

function persistToken(token) {
  localStorage.setItem("exerciseLeaderboardToken", JSON.stringify({ token, storedAt: Date.now() }));
}

function clearStoredSession() {
  localStorage.removeItem("exerciseLeaderboardToken");
  localStorage.removeItem("exerciseLeaderboardOAuthState");
  localStorage.removeItem("exerciseLeaderboardCodeVerifier");
}

function randomString(length = 64) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => chars[byte % chars.length]).join("");
}

function base64UrlEncode(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function sha256Base64Url(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return base64UrlEncode(digest);
}

function clearQueryParams() {
  const url = new URL(window.location.href);
  ["code", "state", "error", "error_description"].forEach((key) => url.searchParams.delete(key));
  history.replaceState({}, document.title, url.toString());
}

function authReady() {
  return Boolean(cfg.GITHUB_CLIENT_ID && cfg.GITHUB_ORG_SLUG);
}

function dataRepoReady() {
  return Boolean(cfg.DATA_REPO_OWNER && cfg.DATA_REPO_NAME && cfg.MANIFEST_PATH && cfg.SOURCES_ZIP_PATH);
}

function isAdminLogin(login) {
  return Array.isArray(cfg.ADMIN_LOGINS) && cfg.ADMIN_LOGINS.includes(login);
}

async function beginGitHubLogin() {
  if (!authReady()) {
    setStatus("GitHub auth is turned on, but the client ID or organization slug is missing.", "warning");
    return;
  }

  const stateValue = randomString(40);
  const codeVerifier = randomString(96);
  const codeChallenge = await sha256Base64Url(codeVerifier);
  localStorage.setItem("exerciseLeaderboardOAuthState", stateValue);
  localStorage.setItem("exerciseLeaderboardCodeVerifier", codeVerifier);

  const redirectUri = `${window.location.origin}${window.location.pathname}`;
  const url = new URL("https://github.com/login/oauth/authorize");
  url.searchParams.set("client_id", cfg.GITHUB_CLIENT_ID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("state", stateValue);
  url.searchParams.set("code_challenge", codeChallenge);
  url.searchParams.set("code_challenge_method", "S256");
  url.searchParams.set("allow_signup", "false");
  window.location.href = url.toString();
}

async function exchangeCodeForToken(code) {
  const codeVerifier = localStorage.getItem("exerciseLeaderboardCodeVerifier");
  if (!codeVerifier) {
    throw new Error("Missing PKCE code verifier. Start the login flow again.");
  }

  const redirectUri = `${window.location.origin}${window.location.pathname}`;
  const payload = {
    client_id: cfg.GITHUB_CLIENT_ID,
    code,
    redirect_uri: redirectUri,
    code_verifier: codeVerifier,
  };

  let response;
  if (cfg.TOKEN_EXCHANGE_URL) {
    response = await fetch(cfg.TOKEN_EXCHANGE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } else {
    response = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams(payload),
    });
  }

  if (!response.ok) {
    throw new Error(`Token exchange failed with status ${response.status}.`);
  }

  const data = await response.json();
  if (data.error) throw new Error(data.error_description || data.error);
  if (!data.access_token) throw new Error("GitHub did not return an access token.");

  state.token = data.access_token;
  persistToken(data.access_token);
}

async function githubApi(path, init = {}) {
  if (!state.token) throw new Error("No GitHub token available.");

  const response = await fetch(`https://api.github.com${path}`, {
    ...init,
    headers: {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${state.token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      ...(init.headers || {}),
    },
  });

  if (response.status === 204) return { status: 204, data: null };

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();
  if (!response.ok) {
    throw new Error(typeof data === "string" ? data : data.message || `GitHub request failed (${response.status}).`);
  }
  return { status: response.status, data };
}

async function githubRaw(path) {
  if (!state.token) throw new Error("No GitHub token available.");
  const response = await fetch(`https://api.github.com/repos/${cfg.DATA_REPO_OWNER}/${cfg.DATA_REPO_NAME}/contents/${encodeURIComponent(path).replace(/%2F/g, "/")}?ref=${encodeURIComponent(cfg.DATA_BRANCH)}`, {
    headers: {
      Accept: "application/vnd.github.raw",
      Authorization: `Bearer ${state.token}`,
      "X-GitHub-Api-Version": "2022-11-28",
    },
  });

  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`Could not fetch ${path} (${response.status}).`);
  return response;
}

async function getRepoFileMeta(path) {
  try {
    const encoded = encodeURIComponent(path).replace(/%2F/g, "/");
    const { data } = await githubApi(`/repos/${cfg.DATA_REPO_OWNER}/${cfg.DATA_REPO_NAME}/contents/${encoded}?ref=${encodeURIComponent(cfg.DATA_BRANCH)}`);
    return data;
  } catch (error) {
    if (String(error.message).includes("Not Found")) return null;
    throw error;
  }
}

async function putRepoFile(path, contentBytes, message) {
  const existing = await getRepoFileMeta(path);
  const encoded = encodeURIComponent(path).replace(/%2F/g, "/");
  const body = {
    message,
    content: encodeBase64Bytes(contentBytes),
    branch: cfg.DATA_BRANCH,
  };
  if (existing?.sha) body.sha = existing.sha;

  await githubApi(`/repos/${cfg.DATA_REPO_OWNER}/${cfg.DATA_REPO_NAME}/contents/${encoded}`, {
    method: "PUT",
    body: JSON.stringify(body),
  });
}

async function resolveCurrentUser() {
  const { data } = await githubApi("/user");
  state.currentUser = data;
  state.isAdmin = isAdminLogin(data.login);
}

async function ensureMembership() {
  const { data: orgs } = await githubApi("/user/orgs");
  const inOrg = Array.isArray(orgs) && orgs.some((org) => String(org.login).toLowerCase() === String(cfg.GITHUB_ORG_SLUG).toLowerCase());
  if (!inOrg) {
    throw new Error(`Signed in as ${state.currentUser.login}, but that account is not in ${cfg.GITHUB_ORG_SLUG}.`);
  }

  if (cfg.GITHUB_TEAM_SLUG) {
    const { data: teams } = await githubApi("/user/teams");
    const inTeam = Array.isArray(teams) && teams.some((team) => {
      const orgMatch = String(team.organization?.login || "").toLowerCase() === String(cfg.GITHUB_ORG_SLUG).toLowerCase();
      const teamMatch = String(team.slug || "").toLowerCase() === String(cfg.GITHUB_TEAM_SLUG).toLowerCase();
      return orgMatch && teamMatch;
    });

    if (!inTeam) {
      throw new Error(`You are in ${cfg.GITHUB_ORG_SLUG}, but not in the required team ${cfg.GITHUB_TEAM_SLUG}.`);
    }
  }
}

async function loadPublishedManifest() {
  if (!dataRepoReady()) {
    logAdmin("No private data repo configured yet. Upload preview still works locally.");
    return;
  }

  const response = await githubRaw(cfg.MANIFEST_PATH);
  if (!response) {
    logAdmin("No published manifest was found yet. Upload a ZIP and publish the first version.");
    return;
  }

  const manifest = JSON.parse(await response.text());
  state.publishedData = manifest;
}

async function loadBuildStatus() {
  if (!dataRepoReady()) return;
  try {
    const response = await githubRaw(cfg.BUILD_STATUS_PATH);
    if (!response) return;
    state.buildStatus = JSON.parse(await response.text());
  } catch (error) {
    console.warn(error);
  }
}

async function ensurePublishedSourcesLoaded() {
  if (state.sourceZipLoaded || !dataRepoReady()) return;
  const response = await githubRaw(cfg.SOURCES_ZIP_PATH);
  if (!response) throw new Error("Published sources ZIP was not found.");
  const zipBuffer = await response.arrayBuffer();
  await loadSourcesFromZipBuffer(zipBuffer);
  state.sourceZipLoaded = true;
}

async function loadSourcesFromZipBuffer(zipBuffer) {
  state.sourceCache.clear();
  const zip = await JSZip.loadAsync(zipBuffer);
  const texEntries = Object.values(zip.files).filter((entry) => !entry.dir && entry.name.toLowerCase().endsWith(".tex"));

  await Promise.all(texEntries.map(async (entry) => {
    const parsed = parseTexFilename(entry.name);
    if (!parsed) return;
    const content = await entry.async("string");
    state.sourceCache.set(parsed.slug, content);
  }));
}

async function readUploadedFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) throw new Error("Please choose a ZIP or TEX files first.");

  state.sourceCache.clear();
  const entries = [];
  let zipBytes = null;
  let zipName = "latest-exercises.zip";

  if (files.length === 1 && files[0].name.toLowerCase().endsWith(".zip")) {
    zipName = files[0].name;
    zipBytes = await files[0].arrayBuffer();
    const zip = await JSZip.loadAsync(zipBytes);
    for (const entry of Object.values(zip.files)) {
      if (entry.dir || !entry.name.toLowerCase().endsWith(".tex")) continue;
      const parsed = parseTexFilename(entry.name);
      if (!parsed) continue;
      const content = await entry.async("string");
      state.sourceCache.set(parsed.slug, content);
      entries.push(parsed);
    }
  } else {
    const zip = new JSZip();
    for (const file of files) {
      if (!file.name.toLowerCase().endsWith(".tex")) continue;
      const content = await file.text();
      const parsed = parseTexFilename(file.name);
      if (!parsed) continue;
      state.sourceCache.set(parsed.slug, content);
      entries.push(parsed);
      zip.file(`uploaded/${parsed.fileName}`, content);
    }
    zipName = "latest-exercises.zip";
    zipBytes = await zip.generateAsync({ type: "arraybuffer", compression: "DEFLATE", compressionOptions: { level: 6 } });
  }

  if (!entries.length) {
    throw new Error("No valid .tex exercise files were found in the upload.");
  }

  return { entries, zipBytes, zipName };
}

async function previewUpload() {
  const { entries, zipBytes, zipName } = await readUploadedFiles(els.zipInput.files);
  state.workingZipBytes = zipBytes;
  state.workingZipName = zipName;
  state.workingData = buildManifest(entries, `Preview from ${zipName}`, zipName);
  state.sourceZipLoaded = true;
  renderAll();
  logAdmin(`Preview built from ${zipName}: ${entries.length} exercises, ${state.workingData.summary.uniquePeople} people.`);
}

function downloadTextFile(fileName, content, type = "application/json;charset=utf-8") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
}

async function publishToPrivateRepo() {
  if (!state.isAdmin) throw new Error("Only the configured admin account can publish.");
  if (!state.workingData || !state.workingZipBytes) throw new Error("Preview an upload before publishing.");
  if (!dataRepoReady()) throw new Error("The private data repo settings are missing in config.js.");

  const manifestBytes = new TextEncoder().encode(JSON.stringify(state.workingData, null, 2));
  const zipBytes = new Uint8Array(state.workingZipBytes);
  const timestamp = new Date().toISOString();

  await putRepoFile(cfg.MANIFEST_PATH, manifestBytes, `Update manifest ${timestamp}`);
  logAdmin(`Published ${cfg.MANIFEST_PATH}.`);
  await putRepoFile(cfg.SOURCES_ZIP_PATH, zipBytes, `Update exercise sources ${timestamp}`);
  logAdmin(`Published ${cfg.SOURCES_ZIP_PATH}.`);

  state.publishedData = JSON.parse(JSON.stringify(state.workingData));
  renderAll();
}

function switchTab(name) {
  const showLatex = name === "latex";
  els.latexTab.classList.toggle("active", showLatex);
  els.pdfTab.classList.toggle("active", !showLatex);
  els.latexPane.classList.toggle("active", showLatex);
  els.pdfPane.classList.toggle("active", !showLatex);
}

async function loadPdfForExercise(exercise) {
  if (!exercise) return;

  if (state.pdfUrlCache.has(exercise.slug)) {
    els.pdfFrame.src = state.pdfUrlCache.get(exercise.slug);
    els.pdfFrame.classList.remove("hidden");
    els.pdfFallback.classList.add("hidden");
    return;
  }

  els.pdfFrame.classList.add("hidden");
  els.pdfFallback.classList.remove("hidden");
  els.pdfFallback.textContent = "Loading PDF…";

  try {
    if (!state.accessGranted || !dataRepoReady()) {
      throw new Error("PDF preview needs private repo access. In local preview mode you can still use the LaTeX tab.");
    }
    const response = await githubRaw(exercise.pdfPath);
    if (!response) {
      throw new Error("This PDF is not available yet. Publish the ZIP and let the private repo workflow generate PDFs first.");
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    state.pdfUrlCache.set(exercise.slug, url);
    els.pdfFrame.src = url;
    els.pdfFrame.classList.remove("hidden");
    els.pdfFallback.classList.add("hidden");
  } catch (error) {
    const buildHint = state.buildStatus?.failureCount
      ? ` Latest PDF build had ${state.buildStatus.failureCount} failure${state.buildStatus.failureCount === 1 ? "" : "s"}.`
      : "";
    els.pdfFallback.textContent = `${error.message}${buildHint}`;
    els.pdfFrame.classList.add("hidden");
  }
}

async function getLatexForExercise(exercise) {
  if (state.sourceCache.has(exercise.slug)) return state.sourceCache.get(exercise.slug);
  await ensurePublishedSourcesLoaded();
  if (!state.sourceCache.has(exercise.slug)) {
    throw new Error("Could not find the LaTeX source for this exercise in the published ZIP.");
  }
  return state.sourceCache.get(exercise.slug);
}

function findExerciseBySlug(slug) {
  return getActiveData().exercises.find((item) => item.slug === slug) || null;
}

async function openExercise(slug) {
  const exercise = findExerciseBySlug(slug);
  if (!exercise) return;
  state.lastModalExercise = exercise;

  els.modalEyebrow.textContent = exercise.section;
  els.modalTitle.textContent = exercise.exerciseId;
  els.modalSubtitle.textContent = `${exercise.person} • ${exercise.fileName}`;
  els.modalMeta.innerHTML = `
    <span class="meta-pill">${escapeHtml(exercise.section)}</span>
    <span class="meta-pill">${escapeHtml(exercise.exerciseNumber)}</span>
    <span class="meta-pill">${escapeHtml(exercise.person)}</span>
  `;

  els.latexContent.textContent = "Loading source…";
  els.pdfFallback.textContent = "Loading PDF…";
  els.pdfFrame.src = "";
  els.pdfFrame.classList.add("hidden");
  els.pdfFallback.classList.remove("hidden");
  switchTab("latex");

  if (!els.exerciseModal.open) {
    els.exerciseModal.showModal();
  }

  try {
    els.latexContent.textContent = await getLatexForExercise(exercise);
  } catch (error) {
    els.latexContent.textContent = error.message;
  }

  await loadPdfForExercise(exercise);
}

function closeModal() {
  if (els.exerciseModal.open) els.exerciseModal.close();
}

function downloadCurrentTex() {
  const exercise = state.lastModalExercise;
  if (!exercise) return;
  const content = els.latexContent.textContent || "";
  downloadTextFile(exercise.fileName, content, "application/x-tex;charset=utf-8");
}

async function openCurrentPdf() {
  const exercise = state.lastModalExercise;
  if (!exercise) return;
  await loadPdfForExercise(exercise);
  const url = state.pdfUrlCache.get(exercise.slug);
  if (url) window.open(url, "_blank", "noopener");
}

async function restoreSessionFromUrl() {
  if (!cfg.AUTH_ENABLED) {
    state.accessGranted = true;
    state.isAdmin = true;
    setStatus("Auth is disabled in config.js. Local preview mode is active.", "warning");
    els.appContent.classList.remove("hidden");
    return;
  }

  if (!authReady()) {
    setStatus("Fill in the GitHub auth settings in config.js first.", "warning");
    return;
  }

  const url = new URL(window.location.href);
  const code = url.searchParams.get("code");
  const returnedState = url.searchParams.get("state");
  const storedState = localStorage.getItem("exerciseLeaderboardOAuthState");

  if (code) {
    if (!storedState || returnedState !== storedState) {
      throw new Error("OAuth state check failed. Start the login flow again.");
    }
    await exchangeCodeForToken(code);
    clearQueryParams();
  } else {
    state.token = readStoredToken();
  }

  if (!state.token) {
    setStatus("Sign in with GitHub to open the private exercise website.", "muted");
    return;
  }

  await resolveCurrentUser();
  await ensureMembership();
  state.accessGranted = true;
  setStatus(`Signed in as ${state.currentUser.login}. Access granted.`, "success");
  els.appContent.classList.remove("hidden");
}

async function initialize() {
  els.appTitle.textContent = cfg.APP_TITLE;
  document.title = cfg.APP_TITLE;

  els.loginButton.addEventListener("click", beginGitHubLogin);
  els.logoutButton.addEventListener("click", () => {
    clearStoredSession();
    state.token = null;
    window.location.reload();
  });
  els.clearPersonFilterButton.addEventListener("click", () => {
    state.selectedPerson = null;
    renderAll();
  });
  els.leaderboardSearch.addEventListener("input", renderLeaderboard);
  els.sortSelect.addEventListener("change", renderLeaderboard);
  els.exerciseSearch.addEventListener("input", renderExercisesAndSummary);
  els.sectionFilter.addEventListener("change", renderExercisesAndSummary);
  els.previewButton.addEventListener("click", async () => {
    try {
      await previewUpload();
    } catch (error) {
      logAdmin(error.message);
      alert(error.message);
    }
  });
  els.publishButton.addEventListener("click", async () => {
    try {
      await publishToPrivateRepo();
      alert("Published to the private repo. The PDF workflow can now generate the PDFs.");
    } catch (error) {
      logAdmin(error.message);
      alert(error.message);
    }
  });
  els.downloadManifestButton.addEventListener("click", () => {
    const data = getActiveData();
    downloadTextFile("manifest.json", JSON.stringify(data, null, 2));
  });
  els.closeModalButton.addEventListener("click", closeModal);
  els.exerciseModal.addEventListener("click", (event) => {
    if (event.target === els.exerciseModal) closeModal();
  });
  els.latexTab.addEventListener("click", () => switchTab("latex"));
  els.pdfTab.addEventListener("click", () => switchTab("pdf"));
  els.openLatexTabButton.addEventListener("click", () => switchTab("latex"));
  els.openPdfTabButton.addEventListener("click", async () => {
    switchTab("pdf");
    await loadPdfForExercise(state.lastModalExercise);
  });
  els.downloadTexButton.addEventListener("click", downloadCurrentTex);
  els.downloadPdfButton.addEventListener("click", openCurrentPdf);

  try {
    await restoreSessionFromUrl();
    if (!cfg.AUTH_ENABLED || state.accessGranted) {
      els.appContent.classList.remove("hidden");
      if (!cfg.AUTH_ENABLED) {
        els.loginButton.classList.add("hidden");
        els.logoutButton.classList.add("hidden");
      } else {
        els.logoutButton.classList.toggle("hidden", !state.accessGranted);
        els.loginButton.classList.toggle("hidden", state.accessGranted);
      }
      if (cfg.AUTH_ENABLED) {
        await loadPublishedManifest();
        await loadBuildStatus();
      }
      renderAll();
    }
  } catch (error) {
    clearStoredSession();
    setStatus(error.message, "danger");
    els.loginButton.classList.remove("hidden");
    els.logoutButton.classList.add("hidden");
    console.error(error);
  }
}

function renderExercisesAndSummary() {
  renderPersonSummary();
  renderExercises();
}

initialize();
