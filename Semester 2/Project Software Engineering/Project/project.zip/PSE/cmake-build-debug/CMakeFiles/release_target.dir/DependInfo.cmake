
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Users/AbEms/CLionProjects/PSE/main.cpp" "CMakeFiles/release_target.dir/main.cpp.obj" "gcc" "CMakeFiles/release_target.dir/main.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/specificatie_1/simulation.cpp" "CMakeFiles/release_target.dir/specificatie_1/simulation.cpp.obj" "gcc" "CMakeFiles/release_target.dir/specificatie_1/simulation.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/elementen/Baan.cpp" "CMakeFiles/release_target.dir/src/Elementen/Baan.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/Elementen/Baan.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/elementen/Verkeerslicht.cpp" "CMakeFiles/release_target.dir/src/Elementen/Verkeerslicht.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/Elementen/Verkeerslicht.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/elementen/Voertuig.cpp" "CMakeFiles/release_target.dir/src/Elementen/Voertuig.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/Elementen/Voertuig.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/elementen/Voertuiggenerator.cpp" "CMakeFiles/release_target.dir/src/Elementen/Voertuiggenerator.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/Elementen/Voertuiggenerator.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/TinyXML/tinystr.cpp" "CMakeFiles/release_target.dir/src/TinyXML/tinystr.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/TinyXML/tinystr.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/TinyXML/tinyxml.cpp" "CMakeFiles/release_target.dir/src/TinyXML/tinyxml.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/TinyXML/tinyxml.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/TinyXML/tinyxmlerror.cpp" "CMakeFiles/release_target.dir/src/TinyXML/tinyxmlerror.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/TinyXML/tinyxmlerror.cpp.obj.d"
  "C:/Users/AbEms/CLionProjects/PSE/src/TinyXML/tinyxmlparser.cpp" "CMakeFiles/release_target.dir/src/TinyXML/tinyxmlparser.cpp.obj" "gcc" "CMakeFiles/release_target.dir/src/TinyXML/tinyxmlparser.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
