file(REMOVE_RECURSE
  "CMakeFiles/debug_target.dir/specificatie_1/simulation.cpp.obj"
  "CMakeFiles/debug_target.dir/specificatie_1/simulation.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinystr.cpp.obj"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinystr.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxml.cpp.obj"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxml.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxmlerror.cpp.obj"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxmlerror.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxmlparser.cpp.obj"
  "CMakeFiles/debug_target.dir/src/TinyXML/tinyxmlparser.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/elementen/Baan.cpp.obj"
  "CMakeFiles/debug_target.dir/src/elementen/Baan.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/elementen/Verkeerslicht.cpp.obj"
  "CMakeFiles/debug_target.dir/src/elementen/Verkeerslicht.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/elementen/Voertuig.cpp.obj"
  "CMakeFiles/debug_target.dir/src/elementen/Voertuig.cpp.obj.d"
  "CMakeFiles/debug_target.dir/src/elementen/Voertuiggenerator.cpp.obj"
  "CMakeFiles/debug_target.dir/src/elementen/Voertuiggenerator.cpp.obj.d"
  "CMakeFiles/debug_target.dir/test/specificatie1/1_1_verkeerssituatie_inlezen/SimulationTESTS.cpp.obj"
  "CMakeFiles/debug_target.dir/test/specificatie1/1_1_verkeerssituatie_inlezen/SimulationTESTS.cpp.obj.d"
  "debug_target.exe"
  "debug_target.exe.manifest"
  "debug_target.pdb"
  "libdebug_target.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/debug_target.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
