var class_baan =
[
    [ "Baan", "class_baan.html#aaa9da4f2adc6cba1caa55054b7897548", null ],
    [ "Baan", "class_baan.html#a2d2ad5bae3ba6cf8bb0dd6e2476c72c1", null ],
    [ "getLengte", "class_baan.html#aa70cd651ed7c533ebb1543dd72baab3f", null ],
    [ "getNaam", "class_baan.html#ac1ce848cc545d73635539c88834d49d6", null ],
    [ "setLengte", "class_baan.html#aff5a6a25beee7079ecb5bf714c70ea8b", null ],
    [ "setNaam", "class_baan.html#a8fc011fd0d6dd234ff928638587425d6", null ]
];