var class_illegal_argument_exception =
[
    [ "IllegalArgumentException", "class_illegal_argument_exception.html#a9e3c5035e787b73c6399414837fe232b", null ],
    [ "what", "class_illegal_argument_exception.html#aed7323169c087bea5743ab32388f4f1d", null ]
];