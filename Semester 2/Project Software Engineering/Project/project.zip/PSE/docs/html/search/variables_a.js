var searchData=
[
  ['simulatie_5ftijd_0',['SIMULATIE_TIJD',['../_constants_8h.html#a41229ee3c6be51bdb65a0ad0f9d06057',1,'Constants.h']]],
  ['stop_5fafstand_1',['STOP_AFSTAND',['../_constants_8h.html#a9ab91344fbfc6725d9a8f44260d92cc6',1,'Constants.h']]]
];
