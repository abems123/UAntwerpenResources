var searchData=
[
  ['col_0',['col',['../struct_ti_xml_cursor.html#a5694d7ed2c4d20109d350c14c417969d',1,'TiXmlCursor']]],
  ['cyclus_1',['cyclus',['../class_verkeerslicht.html#a598a3c805427470ba5e22fc0e4b1041c',1,'Verkeerslicht']]]
];
