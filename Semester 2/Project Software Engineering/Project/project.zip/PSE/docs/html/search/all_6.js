var searchData=
[
  ['getbaan_0',['getBaan',['../class_verkeerslicht.html#ac3ef56343cb5b2e583420ce1a3b825c7',1,'Verkeerslicht::getBaan()'],['../class_voertuig.html#ab590513e9be2563c24af26ed06478139',1,'Voertuig::getBaan()'],['../class_voertuiggenerator.html#ad964d376cbd76302e9f0193098f924b2',1,'Voertuiggenerator::getBaan()']]],
  ['getchar_1',['GetChar',['../class_ti_xml_base.html#a5c309eba97f91f719e7834f6a7ddaf22',1,'TiXmlBase']]],
  ['getcyclus_2',['getCyclus',['../class_verkeerslicht.html#af9a14dcf98139ce70abcfaf04512e126',1,'Verkeerslicht']]],
  ['getdocument_3',['GetDocument',['../class_ti_xml_node.html#adcb070acefcbaedaa0673d82e530538b',1,'TiXmlNode::GetDocument() const'],['../class_ti_xml_node.html#a06c93ecc42b765af56180ce2671fbbf0',1,'TiXmlNode::GetDocument()']]],
  ['getentity_4',['GetEntity',['../class_ti_xml_base.html#ac5c08bf3deffcda0bf8ce2958372b584',1,'TiXmlBase']]],
  ['getfrequentie_5',['getFrequentie',['../class_voertuiggenerator.html#aa4bf8478c5847194b957cbf51925667f',1,'Voertuiggenerator']]],
  ['getid_6',['getId',['../class_voertuig.html#a50b47e4be47b63000f0c841858755392',1,'Voertuig']]],
  ['getkvmax_7',['getKvmax',['../class_voertuig.html#ad459051b4b1a2f34fc6ed7fa363991e8',1,'Voertuig']]],
  ['getlengte_8',['getLengte',['../class_baan.html#aa70cd651ed7c533ebb1543dd72baab3f',1,'Baan']]],
  ['getlength_9',['getLength',['../class_voertuig.html#a1853ca420d6858e8cc3da7f2ec5e0cf1',1,'Voertuig']]],
  ['getnaam_10',['getNaam',['../class_baan.html#ac1ce848cc545d73635539c88834d49d6',1,'Baan']]],
  ['getpositie_11',['getPositie',['../class_verkeerslicht.html#aef0ef7d4d19f93aa125ccb6dc2c00682',1,'Verkeerslicht::getPositie()'],['../class_voertuig.html#ab16d7e812605a6ade8fa8a2bfdddb1ee',1,'Voertuig::getPositie() const']]],
  ['getsnelheid_12',['getSnelheid',['../class_voertuig.html#aba6a3376b3c8f08641d3bc4c8a22d634',1,'Voertuig']]],
  ['gettext_13',['GetText',['../class_ti_xml_element.html#af0f814ecbd43d50d4cdbdf4354d3da39',1,'TiXmlElement']]],
  ['gettijdsindslaatsteverandering_14',['getTijdSindsLaatsteVerandering',['../class_verkeerslicht.html#a49d3a527b41ad158155085c394c5ea7f',1,'Verkeerslicht']]],
  ['getuserdata_15',['GetUserData',['../class_ti_xml_base.html#a436b80c865d437835d370a9eada6f9f5',1,'TiXmlBase::GetUserData()'],['../class_ti_xml_base.html#aa44896ae7cc0e9b1007429b150a81d92',1,'TiXmlBase::GetUserData() const']]],
  ['getversnelling_16',['getVersnelling',['../class_voertuig.html#a28912162917a45d9c774c0575e0b48af',1,'Voertuig']]],
  ['groen_17',['groen',['../class_verkeerslicht.html#a96171ad2d3460648ac4c8f453387277d',1,'Verkeerslicht']]]
];
