var searchData=
[
  ['unknown_0',['Unknown',['../class_ti_xml_handle.html#aa7a8756af3ac24f0b2d469e500b85824',1,'TiXmlHandle']]],
  ['updatetijdsindslaatsteverandering_1',['updateTijdSindsLaatsteVerandering',['../class_verkeerslicht.html#a154338e38d93434f82d57aa594d54fc9',1,'Verkeerslicht']]],
  ['updateverkeerslicht_2',['updateVerkeersLicht',['../class_verkeerslicht.html#a9ea759c8771df8779d65f0ee5d85d230',1,'Verkeerslicht']]],
  ['updateversnellingvoorstoppen_3',['UpdateVersnellingVoorStoppen',['../class_voertuig.html#a157838571f81ad6eab29b008d6e70d87',1,'Voertuig']]]
];
