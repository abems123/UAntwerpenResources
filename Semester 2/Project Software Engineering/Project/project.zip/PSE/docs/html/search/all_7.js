var searchData=
[
  ['herstartcyclus_0',['herstartCyclus',['../class_verkeerslicht.html#ad2fc3302326aad01c250c95e3e33c1b4',1,'Verkeerslicht']]]
];
