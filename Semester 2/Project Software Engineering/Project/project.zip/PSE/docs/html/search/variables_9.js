var searchData=
[
  ['rood_0',['rood',['../class_verkeerslicht.html#aa292a0117bf21837ea202ab5c4326212',1,'Verkeerslicht']]],
  ['row_1',['row',['../struct_ti_xml_cursor.html#a5b54dd949820c2db061e2be41f3effb3',1,'TiXmlCursor']]]
];
