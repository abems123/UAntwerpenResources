var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw~",
  1: "bitv",
  2: "bcdetv",
  3: "abcdefghilnopqrstuvw~",
  4: "bcefglmnprstuv",
  5: "s",
  6: "nt",
  7: "t",
  8: "t",
  9: "ert",
  10: "dl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Pages"
};

