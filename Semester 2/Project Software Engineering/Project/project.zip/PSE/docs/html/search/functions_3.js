var searchData=
[
  ['data_0',['data',['../class_ti_xml_string.html#a1ab72f7ca9911674105dac346793bb9c',1,'TiXmlString']]],
  ['doublevalue_1',['DoubleValue',['../class_ti_xml_attribute.html#a8cca240fb2a7130c87b0fc6156e8b34f',1,'TiXmlAttribute']]]
];
