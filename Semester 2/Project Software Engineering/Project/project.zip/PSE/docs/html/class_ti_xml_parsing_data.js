var class_ti_xml_parsing_data =
[
    [ "Cursor", "class_ti_xml_parsing_data.html#af293019e0dd114e20d64e0abd0e36d7d", null ],
    [ "Stamp", "class_ti_xml_parsing_data.html#a65cee8ab77a36c605db08c84b4c30a7d", null ],
    [ "TiXmlDocument", "class_ti_xml_parsing_data.html#a173617f6dfe902cf484ce5552b950475", null ]
];