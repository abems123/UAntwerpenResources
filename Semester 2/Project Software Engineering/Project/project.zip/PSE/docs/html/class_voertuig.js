var class_voertuig =
[
    [ "Voertuig", "class_voertuig.html#a51f93adeeae5baa16a4200d1a759e206", null ],
    [ "Voertuig", "class_voertuig.html#a8ae5502ec70a058b5f66d039889a8511", null ],
    [ "getBaan", "class_voertuig.html#ab590513e9be2563c24af26ed06478139", null ],
    [ "getId", "class_voertuig.html#a50b47e4be47b63000f0c841858755392", null ],
    [ "getKvmax", "class_voertuig.html#ad459051b4b1a2f34fc6ed7fa363991e8", null ],
    [ "getLength", "class_voertuig.html#a1853ca420d6858e8cc3da7f2ec5e0cf1", null ],
    [ "getPositie", "class_voertuig.html#ab16d7e812605a6ade8fa8a2bfdddb1ee", null ],
    [ "getSnelheid", "class_voertuig.html#aba6a3376b3c8f08641d3bc4c8a22d634", null ],
    [ "getVersnelling", "class_voertuig.html#a28912162917a45d9c774c0575e0b48af", null ],
    [ "setBaan", "class_voertuig.html#ae84f83640452f8d9fea5bf506740eab5", null ],
    [ "setId", "class_voertuig.html#a2a0d4c0efec91a10f84a8aa8fab6307c", null ],
    [ "setKvmax", "class_voertuig.html#a0ec0a9b4deabd0158afab4bd55f28eb4", null ],
    [ "setPositie", "class_voertuig.html#a91afb7e4cc0f6c7dd98ac9d3e0b5e642", null ],
    [ "setSnelheid", "class_voertuig.html#a7c6ef4079a64dbce16a549c8549335f3", null ],
    [ "setVersnelling", "class_voertuig.html#af45a6da5c5acd44b48a5af9e1bfc78a4", null ],
    [ "UpdateVersnellingVoorStoppen", "class_voertuig.html#a157838571f81ad6eab29b008d6e70d87", null ]
];