var _constants_8h =
[
    [ "LENGTE", "_constants_8h.html#aef12042028a930e272dbb44a0ec03353", null ],
    [ "MAX_REMFACTOR", "_constants_8h.html#af089157a6783fe75b59dfbb09b3c0452", null ],
    [ "MAX_SNELHEID", "_constants_8h.html#a039e6c7b940e5bc9954e266af715245e", null ],
    [ "MAX_VERSNELLING", "_constants_8h.html#ab8649fb41bed2ba60413cfb349a42da1", null ],
    [ "MIN_VOLGAFSTAND", "_constants_8h.html#a1e5b7fe341859a2eb07752d77513d3cd", null ],
    [ "SIMULATIE_TIJD", "_constants_8h.html#a41229ee3c6be51bdb65a0ad0f9d06057", null ],
    [ "STOP_AFSTAND", "_constants_8h.html#a9ab91344fbfc6725d9a8f44260d92cc6", null ],
    [ "VERTRAAG_AFSTAND", "_constants_8h.html#aac15d4df8ef91fc1c6a198eccf33c750", null ],
    [ "VERTRAAG_FACTOR", "_constants_8h.html#a28c71004566d4eb078b193cd11d30465", null ]
];