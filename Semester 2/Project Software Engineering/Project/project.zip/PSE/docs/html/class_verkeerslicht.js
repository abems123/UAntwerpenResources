var class_verkeerslicht =
[
    [ "getBaan", "class_verkeerslicht.html#ac3ef56343cb5b2e583420ce1a3b825c7", null ],
    [ "getCyclus", "class_verkeerslicht.html#af9a14dcf98139ce70abcfaf04512e126", null ],
    [ "getPositie", "class_verkeerslicht.html#aef0ef7d4d19f93aa125ccb6dc2c00682", null ],
    [ "getTijdSindsLaatsteVerandering", "class_verkeerslicht.html#a49d3a527b41ad158155085c394c5ea7f", null ],
    [ "herstartCyclus", "class_verkeerslicht.html#ad2fc3302326aad01c250c95e3e33c1b4", null ],
    [ "isGroen", "class_verkeerslicht.html#a7078aa95b2cc0a877d711f46bceca8dd", null ],
    [ "isRood", "class_verkeerslicht.html#a557fe1a19418b8c9b39e1fa751b8024c", null ],
    [ "setBaan", "class_verkeerslicht.html#a89ecdde5ee713999da3a0765865fe246", null ],
    [ "setCyclus", "class_verkeerslicht.html#a2b06390ad713b96583d3a967a55f77ba", null ],
    [ "setGroen", "class_verkeerslicht.html#a6674dcb0f276a261142034c3e6aefe22", null ],
    [ "setPositie", "class_verkeerslicht.html#a43dd9d465b4cf7ee9d7f639c24ec43e8", null ],
    [ "setRood", "class_verkeerslicht.html#af187f68194bcaf771c82231d32a0a499", null ],
    [ "updateTijdSindsLaatsteVerandering", "class_verkeerslicht.html#a154338e38d93434f82d57aa594d54fc9", null ],
    [ "updateVerkeersLicht", "class_verkeerslicht.html#a9ea759c8771df8779d65f0ee5d85d230", null ],
    [ "baan", "class_verkeerslicht.html#a1d1f84897bfed8270ced62d44873ddd6", null ],
    [ "cyclus", "class_verkeerslicht.html#a598a3c805427470ba5e22fc0e4b1041c", null ],
    [ "groen", "class_verkeerslicht.html#a96171ad2d3460648ac4c8f453387277d", null ],
    [ "positie", "class_verkeerslicht.html#a4eff2326dd9362523c062c6f7fc692eb", null ],
    [ "rood", "class_verkeerslicht.html#aa292a0117bf21837ea202ab5c4326212", null ],
    [ "tijdSindsLaatsteVerandering", "class_verkeerslicht.html#a8a05b817e85e26e16795a7a6ae238a61", null ]
];