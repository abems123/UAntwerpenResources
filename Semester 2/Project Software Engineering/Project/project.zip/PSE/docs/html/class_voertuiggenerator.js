var class_voertuiggenerator =
[
    [ "getBaan", "class_voertuiggenerator.html#ad964d376cbd76302e9f0193098f924b2", null ],
    [ "getFrequentie", "class_voertuiggenerator.html#aa4bf8478c5847194b957cbf51925667f", null ],
    [ "setBaan", "class_voertuiggenerator.html#ab714038197bcd183a79dbc228710a3bd", null ],
    [ "setFrequentie", "class_voertuiggenerator.html#a488b9a593abb0790e8d68113b1098779", null ]
];