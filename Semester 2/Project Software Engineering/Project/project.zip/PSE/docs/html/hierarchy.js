var hierarchy =
[
    [ "Baan", "class_baan.html", null ],
    [ "exception", null, [
      [ "IllegalArgumentException", "class_illegal_argument_exception.html", null ]
    ] ],
    [ "TiXmlAttributeSet", "class_ti_xml_attribute_set.html", null ],
    [ "TiXmlBase", "class_ti_xml_base.html", [
      [ "TiXmlAttribute", "class_ti_xml_attribute.html", null ],
      [ "TiXmlNode", "class_ti_xml_node.html", [
        [ "TiXmlComment", "class_ti_xml_comment.html", null ],
        [ "TiXmlDeclaration", "class_ti_xml_declaration.html", null ],
        [ "TiXmlDocument", "class_ti_xml_document.html", null ],
        [ "TiXmlElement", "class_ti_xml_element.html", null ],
        [ "TiXmlText", "class_ti_xml_text.html", null ],
        [ "TiXmlUnknown", "class_ti_xml_unknown.html", null ]
      ] ]
    ] ],
    [ "TiXmlCursor", "struct_ti_xml_cursor.html", null ],
    [ "TiXmlHandle", "class_ti_xml_handle.html", null ],
    [ "TiXmlParsingData", "class_ti_xml_parsing_data.html", null ],
    [ "TiXmlString", "class_ti_xml_string.html", [
      [ "TiXmlOutStream", "class_ti_xml_out_stream.html", null ]
    ] ],
    [ "TiXmlVisitor", "class_ti_xml_visitor.html", [
      [ "TiXmlPrinter", "class_ti_xml_printer.html", null ]
    ] ],
    [ "Verkeerslicht", "class_verkeerslicht.html", null ],
    [ "Voertuig", "class_voertuig.html", null ],
    [ "Voertuiggenerator", "class_voertuiggenerator.html", null ]
];