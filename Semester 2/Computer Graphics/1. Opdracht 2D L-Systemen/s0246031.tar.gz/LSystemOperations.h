//
// Created by AbEms on 3/8/2025.
//







#ifndef LSYSTEMOPERATIONS_H
#define LSYSTEMOPERATIONS_H

#include "datastructures.h"
#include "l_parser.h"
#include <string>

#include "easy_image.h"

using namespace std;

class LSystemOperations {

    const double EPSILON = 1e-9; // Small threshold (0.000000001)

public:
    img::EasyImage draw2DLines(vector<Line2D> lines, int size, const Color &bgcolor);

    vector<Line2D> drawLSystem(const LParser::LSystem2D &l_system, Color linesColor);

    string get_next_version(string &txt, const LParser::LSystem2D &ls);

    // This function is used to compare the double because == doesn't work
    bool areEqual(const double a, const double b) const;

};



#endif //LSYSTEMOPERATIONS_H
