//
// Created by AbEms on 3/8/2025.
//

#include "LSystemOperations.h"

#include <cmath>
#include <algorithm>
#include <stack>

img::EasyImage LSystemOperations::draw2DLines(vector<Line2D> lines, int size, const Color &bgcolor) {
    // Giving each variable a start value that is either the largest possible value or the smallest possible one
    double xmin = numeric_limits<double>::max();
    double xmax = numeric_limits<double>::lowest();
    double ymin = numeric_limits<double>::max();
    double ymax = numeric_limits<double>::lowest();

    // Finding the real of each variable in the lines
    for (auto &[p1, p2, _]: lines) {
        xmin = min({xmin, p1.x, p2.x});
        xmax = max({xmax, p1.x, p2.x});
        ymin = min({ymin, p1.y, p2.y});
        ymax = max({ymax, p1.y, p2.y});
    }

    const double xrange = !areEqual(xmax, xmin) ? xmax - xmin : xmax;
    const double yrange = !areEqual(ymax, ymin) ? ymax - ymin : ymax;

    // De grootte van de Image berekenen
    const int imagex = size * (xrange / max(xrange, yrange));
    const int imagey = size * (yrange / max(xrange, yrange));

    img::EasyImage image(imagex, imagey);


    // Coloring the background
    for (int y = 0; y < imagey; y++) {
        for (int x = 0; x < imagex; x++) {
            image(x, y).red = bgcolor.red * 255;
            image(x, y).green = bgcolor.green * 255;
            image(x, y).blue = bgcolor.blue * 255;
        }
    }

    // De lijntekening schalen
    const double d = 0.95 * imagex / xrange;

    // De coordinaten van alle punten vermenigvuldigen met d
    for (auto &[p1, p2, _]: lines) {
        p1.x *= d;
        p1.y *= d;
        p2.x *= d;
        p2.y *= d;
    }

    // De lijtekening verschuiven
    // 1. Berekenen
    double dcx = d * (xmin + xmax) / 2.0;
    double dcy = d * (ymin + ymax) / 2.0;
    double dx = imagex / 2 - dcx;
    double dy = imagey / 2 - dcy;
    // 2. (dx, dy) optellen bij alle punten
    for (auto &[p1, p2, _]: lines) {
        p1.x += dx;
        p2.x += dx;
        p1.y += dy;
        p2.y += dy;
    }


    // De lijnen tekenen op de image
    for (auto &[p1, p2, color]: lines) {
        // De cordinaten van de punten afronden
        int xa = round(p1.x);
        int xb = round(p2.x);
        int ya = round(p1.y);
        int yb = round(p2.y);

        if (xa > xb) {
            swap(xa, xb);
            swap(ya, yb);
        }

        if (xa == xb) {
            // Vertical line
            for (int y = min(ya, yb); y <= max(ya, yb); y++) {
                image(xa, y).red = color.red * 255;
                image(xa, y).blue = color.blue * 255;
                image(xa, y).green = color.green * 255;
            }
        } else if (ya == yb) {
            // Horizontal line
            for (int x = xa; x <= xb; x++) {
                image(x, ya).red = color.red * 255;
                image(x, ya).blue = color.blue * 255;
                image(x, ya).green = color.green * 255;
            }
        } else {
            if (const double m = (p2.y - p1.y) / (p2.x - p1.x);
                (m > 0 && m <= 1) || (m >= -1 && m < 0)) {
                for (int i = 0; i <= ceil(xb) - ceil(xa); i++) {
                    int xi = ceil(xa) + i;
                    int yi = round(ceil(ya) + m * i);

                    image(xi, yi).red = color.red * 255;
                    image(xi, yi).blue = color.blue * 255;
                    image(xi, yi).green = color.green * 255;
                }
            } else if (m > 1) {
                for (int i = 0; i <= ceil(yb) - ceil(ya); i++) {
                    int xi = round(ceil(xa) + i / m);
                    int yi = ceil(ya) + i;

                    image(xi, yi).red = color.red * 255;
                    image(xi, yi).blue = color.blue * 255;
                    image(xi, yi).green = color.green * 255;
                }
            } else {
                if (ya < yb) {
                    swap(xa, xb);
                    swap(ya, yb);
                }

                for (int i = 0; i <= ceil(ya) - ceil(yb); i++) {
                    int xi = round(ceil(xa) + static_cast<double>(i) / abs(m));
                    int yi = ceil(ya) - i; // Decrease y normally

                    image(xi, yi).red = color.red * 255;
                    image(xi, yi).blue = color.blue * 255;
                    image(xi, yi).green = color.green * 255;
                }
            }
        }
    }

    return image;
}

vector<Line2D> LSystemOperations::drawLSystem(const LParser::LSystem2D &l_system, Color linesColor) {
    const int iterations = l_system.get_nr_iterations();
    string l_system_text = l_system.get_initiator();


    vector<Line2D> lines;

    // Generating the last version of our lsystem
    for (int i = 0; i < iterations; i++) {
        l_system_text = get_next_version(l_system_text, l_system);
    }


    // cout << l_system_text << endl;
    int angle = l_system.get_starting_angle();
    const int delta = l_system.get_angle();

    double dx = cos(angle * M_PI / 180.0), dy = sin(angle * M_PI / 180.0); // Direction vector
    double x = 0, y = 0;

    struct State {
        Point2D point;
        double dx, dy;
        int angle;

        State(const Point2D &p, const double dx, const double dy, const int angle)
            : point(p), dx(dx), dy(dy), angle(angle) {
        }
    };

    stack<State> stateStack;

    for (const char &c: l_system_text) {
        if (c == '(') {
            // Push the current state onto the stack
            stateStack.push(State(Point2D(x, y), dx, dy, angle));
            continue;
        }
        if (c == ')') {
            // Pop the state from the stack and restore it
            if (!stateStack.empty()) {
                State state = stateStack.top();
                x = state.point.x;
                y = state.point.y;
                dx = state.dx;
                dy = state.dy;
                angle = state.angle;
                stateStack.pop();
            }
            continue;
        }
        if (c == '+') {
            angle += delta;
            dx = cos(angle * M_PI / 180.0);
            dy = sin(angle * M_PI / 180.0);
            continue;
        }
        if (c == '-') {
            angle -= delta;
            dx = cos(angle * M_PI / 180.0);
            dy = sin(angle * M_PI / 180.0);
            continue;
        }

        if (l_system.draw(c)) {
            double newX = x + dx;
            double newY = y + dy;

            Point2D p1(x, y);
            Point2D p2(newX, newY);

            lines.emplace_back(p1, p2, linesColor);

            x = newX;
            y = newY;
        }
    }

    return lines;
}

string LSystemOperations::get_next_version(string &txt, const LParser::LSystem2D &ls) {
    string result;

    for (const char &c: txt) {
        bool alpha = false;
        for (auto &a: ls.get_alphabet()) {
            if (a == c)
                alpha = true;
        }

        if (!alpha)
            result += c;
        else
            result += ls.get_replacement(c);
    }
    return result;
}

bool LSystemOperations::areEqual(const double a, const double b) const {
    return fabs(a - b) < EPSILON;
}
