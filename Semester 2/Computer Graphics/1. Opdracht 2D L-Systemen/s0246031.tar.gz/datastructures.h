//
// Created by AbEms on 3/6/2025.
//

#ifndef DATASTRUCTURES_H
#define DATASTRUCTURES_H


// =============== My Datastructures ===============
class Color {
public:
    double red, green, blue;

    Color();

    [[nodiscard]] Color(const double red, const double green, const double blue)
        : red(red),
          green(green),
          blue(blue) {
    }
};

class Point2D {
public:
    double x, y;

    Point2D();

    [[nodiscard]] Point2D(const double x, const double y)
        : x(x),
          y(y) {
    }
};

class Line2D {
public:
    Point2D p1, p2;
    Color color;

    Line2D();

    [[nodiscard]] Line2D(const Point2D &p1, const Point2D &p2, const Color &color)
        : p1(p1),
          p2(p2),
          color(color) {
    }
};

// =============== My Datastructures ===============


#endif //DATASTRUCTURES_H
