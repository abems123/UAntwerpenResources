#include "easy_image.h"
#include "ini_configuration.h"

#include <fstream>
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <stack>

#include "datastructures.h"
#include "LSystemOperations.h"
#include "l_parser.h"


using namespace std;



img::EasyImage generate_image(const ini::Configuration &configuration) {
    string l2d_file = configuration["2DLSystem"]["inputfile"];
    int size = configuration["General"]["size"];

    // if (l2d_file == "koch_curve1.L2D") {
    ini::DoubleTuple bgcolor, linesColor;
    configuration["General"]["backgroundcolor"].as_double_tuple_if_exists(bgcolor);
    configuration["2DLSystem"]["color"].as_double_tuple_if_exists(linesColor);

    LParser::LSystem2D l_system;
    LSystemOperations lsop;

    std::ifstream input_stream(l2d_file);

    input_stream >> l_system;
    input_stream.close();


    vector<Line2D> lines = lsop.drawLSystem(l_system, Color(linesColor[0], linesColor[1], linesColor[2]));
    img::EasyImage image = lsop.draw2DLines(lines, size, Color(bgcolor[0], bgcolor[1], bgcolor[2]));

    return image;
    // }
    //
    // return img::EasyImage();
}

int main(int argc, char const *argv[]) {
    int retVal = 0;

    try {
        vector<string> args = vector<string>(argv + 1, argv + argc);
        if (args.empty()) {
            ifstream fileIn("filelist");
            string filelistName;
            while (getline(fileIn, filelistName)) {
                args.push_back(filelistName);
            }
        }
        for (string fileName: args) {
            ini::Configuration conf;
            try {
                ifstream fin(fileName);
                if (fin.peek() == istream::traits_type::eof()) {
                    cout << "Ini file appears empty. Does '" <<
                            fileName << "' exist?" << endl;
                    continue;
                }
                fin >> conf;
                fin.close();
            } catch (ini::ParseException &ex) {
                cerr << "Error parsing file: " << fileName << ": " << ex.what() << endl;
                retVal = 1;
                continue;
            }

            img::EasyImage image = generate_image(conf);
            if (image.get_height() > 0 && image.get_width() > 0) {
                string::size_type pos = fileName.rfind('.');
                if (pos == string::npos) {
                    //filename does not contain a '.' --> append a '.bmp' suffix
                    fileName += ".bmp";
                } else {
                    fileName = fileName.substr(0, pos) + ".bmp";
                }
                try {
                    ofstream f_out(fileName.c_str(), ios::trunc | ios::out | ios::binary);
                    f_out << image;
                } catch (exception &ex) {
                    cerr << "Failed to write image to file: " << ex.what() << endl;
                    retVal = 1;
                }
            } else {
                cout << "Could not generate image for " << fileName << endl;
            }
        }
    } catch (const bad_alloc &exception) {
        //When you run out of memory this exception is thrown. When this happens the return value of the program MUST be '100'.
        //Basically this return value tells our automated test scripts to run your engine on a pc with more memory.
        //(Unless of course you are already consuming the maximum allowed amount of memory)
        //If your engine does NOT adhere to this requirement you risk losing points because then our scripts will
        //mark the test as failed while in reality it just needed a bit more memory
        cerr << "Error: insufficient memory" << endl;
        retVal = 100;
    }
    return retVal;
}
