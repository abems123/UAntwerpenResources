#include "utils/easy_image.h"
#include "utils/ini_configuration.h"

#include <fstream>
#include <iostream>
#include <cmath>
#include <string>

#include "datastructures/vector3d.h"
#include "lparser/l_parser.h"
#include "src/TwoDOperations.h"
#include "src/SpaceFigures.h"
#include "src/ThreeDLSystem.h"
#include "src/Transformations.h"
#include "datastructures/ZBuffer.h"
#include <chrono>

using namespace std;

img::EasyImage generate_image(const ini::Configuration& configuration)
{
    string type = configuration["General"]["type"];
    int size = configuration["General"]["size"];
    ini::DoubleTuple background_color = configuration["General"]["backgroundcolor"].as_double_tuple_or_die();

    Lines2D lines;
    img::EasyImage image;

    bool zbuffering = false;

    if (type == "2DLSystem")
    {
        ini::DoubleTuple bgcolor, linesColor;
        configuration["General"]["backgroundcolor"].as_double_tuple_if_exists(bgcolor);
        configuration["2DLSystem"]["color"].as_double_tuple_if_exists(linesColor);
        string l2d_file = configuration["2DLSystem"]["inputfile"];

        LParser::LSystem2D l_system;
        std::ifstream input_stream(l2d_file);
        input_stream >> l_system;

        lines = TwoDOperations::draw2DLSystem(
            l_system, Color(linesColor[0] * 255, linesColor[1] * 255, linesColor[2] * 255));
        image = TwoDOperations::draw2DLines(lines, size,
                                            Color(background_color[0], background_color[1], background_color[2]),
                                            zbuffering, "2DLSystem");
    }
    else if (type == "Wireframe" || type == "ZBufferedWireframe")
    {
        Matrix v;
        Vector3D eye;
        eye.x = configuration["General"]["eye"].as_double_tuple_or_die()[0];
        eye.y = configuration["General"]["eye"].as_double_tuple_or_die()[1];
        eye.z = configuration["General"]["eye"].as_double_tuple_or_die()[2];
        Figures3D figures;
        int nr_figures = configuration["General"]["nrFigures"];

        for (int i = 0; i < nr_figures; i++)
        {
            Figure figure;
            string current_figure = "Figure" + to_string(i);
            string fig_type = configuration[current_figure]["type"];
            double scale = configuration[current_figure]["scale"].as_double_or_die();
            double rotate_x = configuration[current_figure]["rotateX"].as_double_or_die() * M_PI / 180.0;
            double rotate_y = configuration[current_figure]["rotateY"].as_double_or_die() * M_PI / 180.0;
            double rotate_z = configuration[current_figure]["rotateZ"].as_double_or_die() * M_PI / 180.0;
            ini::DoubleTuple center = configuration[current_figure]["center"];

            ini::DoubleTuple c = configuration[current_figure]["color"];
            img::Color color(c[0] * 255, c[1] * 255, c[2] * 255);

            if (fig_type == "LineDrawing")
            {
                int nr_points = configuration[current_figure]["nrPoints"];
                for (int j = 0; j < nr_points; j++)
                {
                    ini::DoubleTuple point = configuration[current_figure]["point" + to_string(j)];
                    Vector3D p;
                    p.x = point[0];
                    p.y = point[1];
                    p.z = point[2];
                    figure.points.push_back(p);
                }
                int nr_lines = configuration[current_figure]["nrLines"];
                for (int j = 0; j < nr_lines; j++)
                {
                    ini::DoubleTuple line = configuration[current_figure]["line" + to_string(j)];
                    Face f;
                    f.point_indexes.push_back(static_cast<int>(line[0] + 1));
                    f.point_indexes.push_back(static_cast<int>(line[1]) + 1);
                    figure.faces.push_back(f);
                }
            }
            else if (fig_type == "Cube") figure = SpaceFigures::createCube();
            else if (fig_type == "Tetrahedron") figure = SpaceFigures::createTetrahedron();
            else if (fig_type == "Icosahedron") figure = SpaceFigures::createIcosahedron();
            else if (fig_type == "Octahedron") figure = SpaceFigures::createOctahedron();
            else if (fig_type == "Dodecahedron") figure = SpaceFigures::createDodecahedron();
            else if (fig_type == "Cone")
                figure = SpaceFigures::createCone(
                    configuration[current_figure]["n"], configuration[current_figure]["height"]);
            else if (fig_type == "Sphere") figure = SpaceFigures::createSphere(configuration[current_figure]["n"]);
            else if (fig_type == "Cylinder")
                figure = SpaceFigures::createCylinder(
                    configuration[current_figure]["n"], configuration[current_figure]["height"]);
            else if (fig_type == "Torus")
                figure = SpaceFigures::createTorus(
                    configuration[current_figure]["r"], configuration[current_figure]["R"],
                    configuration[current_figure]["n"], configuration[current_figure]["m"]);
            else if (fig_type == "3DLSystem")
            {
                string l3d_file = configuration[current_figure]["inputfile"];
                LParser::LSystem3D l_system;
                std::ifstream input_stream(l3d_file);
                input_stream >> l_system;
                figure = ThreeDLSystem::draw3DLSystem(l_system);
            }
            else if (fig_type == "BuckyBall")
                figure = SpaceFigures::createBuckyBall();
            else if (fig_type == "MengerSponge")
            {
                int iterations = configuration[current_figure]["nrIterations"];
                figure = SpaceFigures::createMengerSponge(iterations);
            }

            else if (fig_type == "FractalTetrahedron" || fig_type == "FractalCube" || fig_type == "FractalOctahedron"
                || fig_type == "FractalIcosahedron" || fig_type == "FractalDodecahedron" || fig_type ==
                "FractalBuckyBall")
            {
                Figure base;
                int nrIterations = configuration[current_figure]["nrIterations"];
                double fractalScale = configuration[current_figure]["fractalScale"];

                if (fig_type == "FractalTetrahedron") base = SpaceFigures::createTetrahedron();
                else if (fig_type == "FractalCube") base = SpaceFigures::createCube();
                else if (fig_type == "FractalOctahedron") base = SpaceFigures::createOctahedron();
                else if (fig_type == "FractalIcosahedron") base = SpaceFigures::createIcosahedron();
                else if (fig_type == "FractalDodecahedron") base = SpaceFigures::createDodecahedron();
                else if (fig_type == "FractalBuckyBall") base = SpaceFigures::createBuckyBall();
                else if (fig_type == "FractalMengerSponge") base = SpaceFigures::createMengerSponge(nrIterations);


                Figures3D fractalResult;
                SpaceFigures::generateFractal(base, fractalResult, nrIterations, fractalScale);

                for (auto& f : fractalResult)
                {
                    f.normalColor = color;
                    Transformations::applyTransformation(f, Transformations::scaleFigure(scale));
                    Transformations::applyTransformation(f, Transformations::rotateX(rotate_x));
                    Transformations::applyTransformation(f, Transformations::rotateY(rotate_y));
                    Transformations::applyTransformation(f, Transformations::rotateZ(rotate_z));
                    Transformations::applyTransformation(
                        f, Transformations::translate(center[0], center[1], center[2]));

                    v = Transformations::eyePointTrans(eye);
                    Transformations::applyTransformation(f, v);
                    figures.push_back(f);
                }
                continue;
            }

            figure.normalColor = color;
            Transformations::applyTransformation(figure, Transformations::scaleFigure(scale));
            Transformations::applyTransformation(figure, Transformations::rotateX(rotate_x));
            Transformations::applyTransformation(figure, Transformations::rotateY(rotate_y));
            Transformations::applyTransformation(figure, Transformations::rotateZ(rotate_z));
            Transformations::applyTransformation(figure, Transformations::translate(center[0], center[1], center[2]));

            v = Transformations::eyePointTrans(eye);
            Transformations::applyTransformation(figure, v);
            figures.push_back(figure);
        }
        lines = Transformations::doProjection(figures);

        if (type != "ZBufferedWireframe")
        {
            image = TwoDOperations::draw2DLines(lines, size,
                                                Color(background_color[0], background_color[1], background_color[2]),
                                                false, "Wireframe");
        }
        else
        {
            image = TwoDOperations::draw2DLines(lines, size,
                                                Color(background_color[0], background_color[1], background_color[2]),
                                                true,"Wireframe");
        }
    }
    else if (type == "ZBuffering")
    {
        Vector3D eye;
        eye.x = configuration["General"]["eye"].as_double_tuple_or_die()[0];
        eye.y = configuration["General"]["eye"].as_double_tuple_or_die()[1];
        eye.z = configuration["General"]["eye"].as_double_tuple_or_die()[2];

        Figures3D figures;
        int nr_figures = configuration["General"]["nrFigures"];

        for (int i = 0; i < nr_figures; i++)
        {
            string current_figure = "Figure" + to_string(i);
            string fig_type = configuration[current_figure]["type"];
            double scale = configuration[current_figure]["scale"].as_double_or_die();
            double rotate_x = configuration[current_figure]["rotateX"].as_double_or_die() * M_PI / 180.0;
            double rotate_y = configuration[current_figure]["rotateY"].as_double_or_die() * M_PI / 180.0;
            double rotate_z = configuration[current_figure]["rotateZ"].as_double_or_die() * M_PI / 180.0;
            ini::DoubleTuple center = configuration[current_figure]["center"];
            ini::DoubleTuple c = configuration[current_figure]["color"];
            img::Color color(c[0] * 255, c[1] * 255, c[2] * 255);

            int n, m, nr_i;
            double h, r, R;
            if (fig_type == "Cone")
            {
                n = configuration[current_figure]["n"];
                h = configuration[current_figure]["height"];
            }
            else if (fig_type == "Sphere")
            {
                n = configuration[current_figure]["n"];
            }
            else if (fig_type == "Cylinder")
            {
                n = configuration[current_figure]["n"];
                h = configuration[current_figure]["height"];
            }
            else if (fig_type == "Torus")
            {
                r = configuration[current_figure]["r"];
                R = configuration[current_figure]["R"];
                n = configuration[current_figure]["n"];
                m = configuration[current_figure]["m"];
            }
            else if (fig_type == "MengerSponge")
            {
                nr_i = configuration[current_figure]["nrIterations"];
            }
            else if (fig_type == "FractalTetrahedron" || fig_type == "FractalCube" || fig_type == "FractalOctahedron"
                || fig_type == "FractalIcosahedron" || fig_type == "FractalDodecahedron" || fig_type ==
                "FractalBuckyBall")
            {
                Figure base;
                int nrIterations = configuration[current_figure]["nrIterations"];
                double fractalScale = configuration[current_figure]["fractalScale"];

                if (fig_type == "FractalTetrahedron") base = SpaceFigures::createTetrahedron();
                else if (fig_type == "FractalCube") base = SpaceFigures::createCube();
                else if (fig_type == "FractalOctahedron") base = SpaceFigures::createOctahedron();
                else if (fig_type == "FractalIcosahedron") base = SpaceFigures::createIcosahedron();
                else if (fig_type == "FractalDodecahedron") base = SpaceFigures::createDodecahedron();
                else if (fig_type == "FractalBuckyBall") base = SpaceFigures::createBuckyBall();
                else if (fig_type == "FractalMengerSponge") base = SpaceFigures::createMengerSponge(nrIterations);


                Figures3D fractalResult;
                SpaceFigures::generateFractal(base, fractalResult, nrIterations, fractalScale);

                for (auto& f : fractalResult)
                {
                    f.normalColor = color;
                    Transformations::applyTransformation(f, Transformations::scaleFigure(scale));
                    Transformations::applyTransformation(f, Transformations::rotateX(rotate_x));
                    Transformations::applyTransformation(f, Transformations::rotateY(rotate_y));
                    Transformations::applyTransformation(f, Transformations::rotateZ(rotate_z));
                    Transformations::applyTransformation(
                        f, Transformations::translate(center[0], center[1], center[2]));

                    Matrix v = Transformations::eyePointTrans(eye);
                    Transformations::applyTransformation(f, v);
                    figures.push_back(f);
                }
                continue;
            }

            Figure figure = SpaceFigures::createFigure(fig_type, n, h, r, R, m, nr_i);
            figure.normalColor = color;

            Transformations::applyTransformation(figure, Transformations::scaleFigure(scale));
            Transformations::applyTransformation(figure, Transformations::rotateX(rotate_x));
            Transformations::applyTransformation(figure, Transformations::rotateY(rotate_y));
            Transformations::applyTransformation(figure, Transformations::rotateZ(rotate_z));
            Transformations::applyTransformation(figure, Transformations::translate(center[0], center[1], center[2]));
            Matrix v = Transformations::eyePointTrans(eye);
            Transformations::applyTransformation(figure, v);
            figures.push_back(figure);
        }


        // Compute bounding box
        double x_min = std::numeric_limits<double>::infinity(), x_max = -x_min;
        double y_min = std::numeric_limits<double>::infinity(), y_max = -y_min;

        for (const auto& fig : figures)
        {
            for (const auto& p : fig.points)
            {
                double x_p = p.x / -p.z;
                double y_p = p.y / -p.z;
                x_min = std::min(x_min, x_p);
                x_max = std::max(x_max, x_p);
                y_min = std::min(y_min, y_p);
                y_max = std::max(y_max, y_p);
            }
        }

        auto are_equal = [](double a, double b)
        {
            return fabs(a - b) < EPSILON;
        };

        const double xrange = !are_equal(x_max, x_min) ? x_max - x_min : x_max;
        const double yrange = !are_equal(y_max, y_min) ? y_max - y_min : y_max;

        // De grootte van de Image berekenen
        double dominator_x = xrange > yrange ? 1 : (xrange / yrange);
        double dominator_y = xrange > yrange ? (yrange / xrange) : 1;

        int imagex = floor(size * dominator_x);
        int imagey = floor(size * dominator_y);

        // std::cout << "Image size: " << imagex << " x " << imagey << std::endl;

        const double d = 0.95 * imagex / xrange;
        const double dcx = d * ((x_min + x_max) / 2.0);
        const double dcy = d * ((y_min + y_max) / 2.0);
        const double dx = imagex / 2.0 - dcx;
        const double dy = imagey / 2.0 - dcy;

        ZBuffer zbuffer(imagex, imagey);
        image = img::EasyImage(imagex, imagey,
                               img::Color(background_color[0] * 255, background_color[1] * 255,
                                          background_color[2] * 255));

        for (auto& figure : figures)
        {
            // Triangulate
            vector<Face> triag_faces;
            int tria_idx = 0;
            // cout << "Figure faces: " << fig.faces.size() << endl;
            for (const auto& f : figure.faces)
            {
                if (f.point_indexes.size() > 3)
                {
                    auto triangles = ZBuffer::triangulate(f);
                    for (auto& t : triangles)
                        triag_faces.push_back(t);
                }
                else
                {
                    triag_faces.push_back(f);
                }
                // cout << "Triangles size: " << tria_idx++ << endl;
            }

            for (const Face& face : triag_faces)
            {
                const Vector3D& A = figure.points[face.point_indexes[0] - 1];
                const Vector3D& B = figure.points[face.point_indexes[1] - 1];
                const Vector3D& C = figure.points[face.point_indexes[2] - 1];


                zbuffer.draw_zbuf_triag(image, A, B, C, d, dx, dy,
                                        img::Color(figure.normalColor.red, figure.normalColor.green,
                                                   figure.normalColor.blue));
            }
        }

        return image;
    }
    else if (type == "LightedZBuffering")
    {
        Vector3D eye;
        eye.x = configuration["General"]["eye"].as_double_tuple_or_die()[0];
        eye.y = configuration["General"]["eye"].as_double_tuple_or_die()[1];
        eye.z = configuration["General"]["eye"].as_double_tuple_or_die()[2];
        Matrix v = Transformations::eyePointTrans(eye);

        Figures3D figures;
        int nr_figures = configuration["General"]["nrFigures"];

        Lights3D lights;
        int nr_lights = configuration["General"]["nrLights"];

        ini::DoubleTuple default_value{-111, -111, -111};

        for (int i = 0; i < nr_lights; i++)
        {
            string current_light = "Light" + to_string(i);

            Light light;

            // Parse ambientLight if present
            ini::DoubleTuple ambient_light = configuration[current_light]["ambientLight"].as_double_tuple_or_default(
                default_value);
            if (ambient_light != default_value)
            {
                light.ambientLight = Color(ambient_light[0], ambient_light[1], ambient_light[2]);
            }

            // Parse diffuseLight if present
            ini::DoubleTuple diffuse_light = configuration[current_light]["diffuseLight"].as_double_tuple_or_default(
                default_value);
            if (diffuse_light != default_value)
            {
                light.diffuseLight = Color(diffuse_light[0], diffuse_light[1], diffuse_light[2]);
            }

            // Parse directional/point light parameters
            bool infinity = configuration[current_light]["infinity"].as_bool_or_default(false);
            light.infinity = infinity;

            if (infinity)
            {
                // directional light
                ini::DoubleTuple direction = configuration[current_light]["direction"].as_double_tuple_or_default(
                    default_value);
                light.direction = Vector3D::vector(direction[0], direction[1], direction[2]);
                // light.direction *= v;
            }
            else
            {
                // point light (optional, only needed if you plan to use it later)
                ini::DoubleTuple location = configuration[current_light]["location"].as_double_tuple_or_default(
                    default_value);
                light.location = Vector3D();
                light.location.x = location[0], light.location.y = location[1], light.location.z = location[2];
            }

            lights.push_back(light);
        }


        for (int i = 0; i < nr_figures; i++)
        {
            string current_figure = "Figure" + to_string(i);
            string fig_type = configuration[current_figure]["type"];
            double scale = configuration[current_figure]["scale"].as_double_or_die();
            double rotate_x = configuration[current_figure]["rotateX"].as_double_or_die() * M_PI / 180.0;
            double rotate_y = configuration[current_figure]["rotateY"].as_double_or_die() * M_PI / 180.0;
            double rotate_z = configuration[current_figure]["rotateZ"].as_double_or_die() * M_PI / 180.0;
            ini::DoubleTuple center = configuration[current_figure]["center"];

            ini::DoubleTuple ambientReflection = configuration[current_figure]["ambientReflection"].
                as_double_tuple_or_default(default_value);
            ini::DoubleTuple diffuseReflection = configuration[current_figure]["diffuseReflection"].
                as_double_tuple_or_default(default_value);

            // applying the same transformations as the ones on figure
            for (auto& l : lights)
            {
                Figure dir_fig;
                dir_fig.points.push_back(l.direction);
                // dir_fig.points.push_back(l.location);
                Transformations::applyTransformation(dir_fig, Transformations::scaleFigure(scale));
                Transformations::applyTransformation(dir_fig, Transformations::rotateX(rotate_x));
                Transformations::applyTransformation(dir_fig, Transformations::rotateY(rotate_y));
                Transformations::applyTransformation(dir_fig, Transformations::rotateZ(rotate_z));
                Transformations::applyTransformation(dir_fig, Transformations::translate(center[0], center[1], center[2]));
                Transformations::applyTransformation(dir_fig, v);
                l.direction = dir_fig.points.front();
                // l.location = dir_fig.points.back();
            }

            int n, m, nr_i;
            double h, r, R;
            if (fig_type == "Cone")
            {
                n = configuration[current_figure]["n"];
                h = configuration[current_figure]["height"];
            }
            else if (fig_type == "Sphere")
            {
                n = configuration[current_figure]["n"];
            }
            else if (fig_type == "Cylinder")
            {
                n = configuration[current_figure]["n"];
                h = configuration[current_figure]["height"];
            }
            else if (fig_type == "Torus")
            {
                r = configuration[current_figure]["r"];
                R = configuration[current_figure]["R"];
                n = configuration[current_figure]["n"];
                m = configuration[current_figure]["m"];
            }
            else if (fig_type == "MengerSponge")
            {
                nr_i = configuration[current_figure]["nrIterations"];
            }
            else if (fig_type == "FractalTetrahedron" || fig_type == "FractalCube" || fig_type == "FractalOctahedron"
                || fig_type == "FractalIcosahedron" || fig_type == "FractalDodecahedron" || fig_type ==
                "FractalBuckyBall")
            {
                Figure base;
                int nrIterations = configuration[current_figure]["nrIterations"];
                double fractalScale = configuration[current_figure]["fractalScale"];

                if (fig_type == "FractalTetrahedron") base = SpaceFigures::createTetrahedron();
                else if (fig_type == "FractalCube") base = SpaceFigures::createCube();
                else if (fig_type == "FractalOctahedron") base = SpaceFigures::createOctahedron();
                else if (fig_type == "FractalIcosahedron") base = SpaceFigures::createIcosahedron();
                else if (fig_type == "FractalDodecahedron") base = SpaceFigures::createDodecahedron();
                else if (fig_type == "FractalBuckyBall") base = SpaceFigures::createBuckyBall();
                else if (fig_type == "FractalMengerSponge") base = SpaceFigures::createMengerSponge(nrIterations);


                base.diffuseReflection.red = diffuseReflection[0];
                base.diffuseReflection.green = diffuseReflection[1];
                base.diffuseReflection.blue = diffuseReflection[2];

                Figures3D fractalResult;
                SpaceFigures::generateFractal(base, fractalResult, nrIterations, fractalScale);

                for (auto& f : fractalResult)
                {
                    f.ambientReflection.red = ambientReflection[0];
                    f.ambientReflection.green = ambientReflection[1];
                    f.ambientReflection.blue = ambientReflection[2];
                    Transformations::applyTransformation(f, Transformations::scaleFigure(scale));
                    Transformations::applyTransformation(f, Transformations::rotateX(rotate_x));
                    Transformations::applyTransformation(f, Transformations::rotateY(rotate_y));
                    Transformations::applyTransformation(f, Transformations::rotateZ(rotate_z));
                    Transformations::applyTransformation(
                        f, Transformations::translate(center[0], center[1], center[2]));

                    v = Transformations::eyePointTrans(eye);
                    Transformations::applyTransformation(f, v);
                    figures.push_back(f);
                }
                continue;
            }

            Figure figure = SpaceFigures::createFigure(fig_type, n, h, r, R, m, nr_i);

            Transformations::applyTransformation(figure, Transformations::scaleFigure(scale));
            Transformations::applyTransformation(figure, Transformations::rotateX(rotate_x));
            Transformations::applyTransformation(figure, Transformations::rotateY(rotate_y));
            Transformations::applyTransformation(figure, Transformations::rotateZ(rotate_z));
            Transformations::applyTransformation(figure, Transformations::translate(center[0], center[1], center[2]));
            Transformations::applyTransformation(figure, v);

            figure.ambientReflection.red = ambientReflection[0];
            figure.ambientReflection.green = ambientReflection[1];
            figure.ambientReflection.blue = ambientReflection[2];

            figure.diffuseReflection.red = diffuseReflection[0];
            figure.diffuseReflection.green = diffuseReflection[1];
            figure.diffuseReflection.blue = diffuseReflection[2];

            figures.push_back(figure);
        }


        // Compute bounding box
        double x_min = std::numeric_limits<double>::infinity(), x_max = -x_min;
        double y_min = std::numeric_limits<double>::infinity(), y_max = -y_min;

        for (const auto& fig : figures)
        {
            for (const auto& p : fig.points)
            {
                double x_p = p.x / -p.z;
                double y_p = p.y / -p.z;
                x_min = std::min(x_min, x_p);
                x_max = std::max(x_max, x_p);
                y_min = std::min(y_min, y_p);
                y_max = std::max(y_max, y_p);
            }
        }

        auto are_equal = [](double a, double b)
        {
            return fabs(a - b) < EPSILON;
        };

        const double xrange = !are_equal(x_max, x_min) ? x_max - x_min : x_max;
        const double yrange = !are_equal(y_max, y_min) ? y_max - y_min : y_max;

        // De grootte van de Image berekenen
        double dominator_x = xrange > yrange ? 1 : (xrange / yrange);
        double dominator_y = xrange > yrange ? (yrange / xrange) : 1;

        int imagex = ceil(size * dominator_x);
        int imagey = ceil(size * dominator_y);

        // std::cout << "Image size: " << imagex << " x " << imagey << std::endl;

        const double d = 0.95 * imagex / xrange;
        const double dcx = d * ((x_min + x_max) / 2.0);
        const double dcy = d * ((y_min + y_max) / 2.0);
        const double dx = imagex / 2.0 - dcx;
        const double dy = imagey / 2.0 - dcy;

        ZBuffer zbuffer(imagex, imagey);
        image = img::EasyImage(imagex, imagey,
                               img::Color(background_color[0] * 255, background_color[1] * 255,
                                          background_color[2] * 255));

        for (auto& figure : figures)
        {
            // Triangulate
            vector<Face> triag_faces;
            // cout << "Figure faces: " << fig.faces.size() << endl;
            for (const auto& f : figure.faces)
            {
                if (f.point_indexes.size() > 3)
                {
                    auto triangles = ZBuffer::triangulate(f);
                    for (auto& t : triangles)
                        triag_faces.push_back(t);
                }
                else
                {
                    triag_faces.push_back(f);
                }
                // cout << "Triangles size: " << tria_idx++ << endl;
            }

            for (const Face& face : triag_faces)
            {
                const Vector3D& A = figure.points[face.point_indexes[0] - 1];
                const Vector3D& B = figure.points[face.point_indexes[1] - 1];
                const Vector3D& C = figure.points[face.point_indexes[2] - 1];


                zbuffer.draw_zbuf_triag(image, A, B, C, d, dx, dy,
                                        figure.ambientReflection, figure.diffuseReflection, figure.specularReflection,
                                        figure.reflectionCoefficient, lights);
            }
        }
    }

    return image;
}

int main(int argc, char const* argv[])
{
    auto start = std::chrono::high_resolution_clock::now();

    int retVal = 0;
    try
    {
        std::vector<std::string> args = std::vector<std::string>(argv + 1, argv + argc);
        if (args.empty())
        {
            std::ifstream fileIn("filelist");
            std::string filelistName;
            while (std::getline(fileIn, filelistName)) args.push_back(filelistName);
        }
        for (std::string fileName : args)
        {
            ini::Configuration conf;
            try
            {
                std::ifstream fin(fileName);
                if (fin.peek() == std::istream::traits_type::eof())
                {
                    std::cout << "Ini file appears empty. Does '" << fileName << "' exist?" << std::endl;
                    continue;
                }
                fin >> conf;
                fin.close();
            }
            catch (ini::ParseException& ex)
            {
                std::cerr << "Error parsing file: " << fileName << ": " << ex.what() << std::endl;
                retVal = 1;
                continue;
            }

            img::EasyImage image = generate_image(conf);
            if (image.get_height() > 0 && image.get_width() > 0)
            {
                std::string::size_type pos = fileName.rfind('.');
                fileName = (pos == std::string::npos) ? fileName + ".bmp" : fileName.substr(0, pos) + ".bmp";
                try
                {
                    std::ofstream f_out(fileName.c_str(), std::ios::trunc | std::ios::out | std::ios::binary);
                    f_out << image;
                }
                catch (std::exception& ex)
                {
                    std::cerr << "Failed to write image to file: " << ex.what() << std::endl;
                    retVal = 1;
                }
            }
            else std::cout << "Could not generate image for " << fileName << std::endl;
        }
    }
    catch (const std::bad_alloc& exception)
    {
        std::cerr << "Error: insufficient memory" << std::endl;
        retVal = 100;
    }

    // // // Add this to your main and specify the directory with images.
    // ImageComparator image_comparator("./");
    // image_comparator.compare();

    // auto end = std::chrono::high_resolution_clock::now();
    // std::chrono::duration<double> duration = end - start;
    // std::cout << "\nTime taken: " << duration.count() << " seconds" << std::endl;

    return retVal;
}
