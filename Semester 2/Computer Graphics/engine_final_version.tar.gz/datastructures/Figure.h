//
// Created by Abdellah on 4/14/2025.
//

#ifndef FIGURE_H
#define FIGURE_H
#include <list>

#include "../utils/easy_image.h"
#include "Face.h"
#include "Color.h"

class Vector3D;

class Figure
{
public:
    vector<Vector3D> points;
    vector<Face> faces;
    img::Color normalColor;
    Color ambientReflection;
    Color diffuseReflection;
    Color specularReflection;
    double reflectionCoefficient;

};
typedef list<Figure> Figures3D;

#endif //FIGURE_H
