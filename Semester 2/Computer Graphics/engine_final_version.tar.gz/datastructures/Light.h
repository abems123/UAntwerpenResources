//
// Created by Abdellah on 5/18/2025.
//

#ifndef LIGHT_H
#define LIGHT_H
#include <list>

#include "Color.h"
#include "vector3d.h"
#include "../utils/easy_image.h"


class Light
{
public:
    //de ambiente licht component
    Color ambientLight;
    //de diffuse licht component
    Color diffuseLight;
    //de diffuse licht component
    Color specularLight;

    bool infinity = false;         // whether it's directional light
    Vector3D direction;
    Vector3D location;
};

using Lights3D = std::list<Light>;

#endif //LIGHT_H
