//
// Created by Abdellah on 4/14/2025.
//

#ifndef FACE_H
#define FACE_H
#include <vector>

using namespace std;

class Face
{

public:
    vector<int> point_indexes;
    Face() = default;

    bool operator==(const Face& other) const {
        return point_indexes == other.point_indexes;
    }
};



#endif //FACE_H
