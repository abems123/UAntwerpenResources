//
// Created by Abdellah on 5/5/2025.
//

#include "ZBuffer.h"

#include <algorithm>

#include "../utils/easy_image.h"

#include <cmath>
#include <map>
#include <sstream>
#include <stdexcept>

#include "Color.h"
#include "Face.h"
#include "Point2D.h"
#include "vector3d.h"

int ZBuffer::getWidth() const
{
    return width;
}

int ZBuffer::getHeight() const
{
    return height;
}


void ZBuffer::draw_zbuf_line(img::EasyImage& image,
                             unsigned int x0, unsigned int y0, double z0,
                             unsigned int x1, unsigned int y1, double z1,
                             const img::Color& color)
{
    if (x0 >= this->width || y0 >= this->height || x1 >= this->width || y1 > this->height)
    {
        std::stringstream ss;
        ss << "Drawing line from (" << x0 << "," << y0 << ") to (" << x1 << "," << y1 << ") in image of width "
            << this->width << " and height " << this->height;
        throw std::runtime_error(ss.str());
    }
    if ((x0 > x1) || ((x0 == x1) && (y0 > y1)))
    {
        // Ensure p0->p1 goes from left to right (or from bottom to top if perfectly vertical)
        std::swap(x0, x1);
        std::swap(y0, y1);
        std::swap(z0, z1);
    }

    double inv_zi;

    if (x0 == x1)
    {
        // Special case for vertical line
        for (int i = 0; i <= (y1 - y0); i++)
        {
            auto x = x0;
            auto y = y0 + i;

            const double p = (double)i / (double)(y1 - y0);
            inv_zi = (1.0 - p) / z0 + p / z1;
            if (inv_zi <= buffer[x][y])
            {
                buffer[x][y] = inv_zi;
                image(x0, y0 + i) = color;
            }
        }
    }
    else if (y0 == y1)
    {
        auto a = x1 - x0;
        // Special case for horizontal line
        for (int i = 0; i <= a; i++)
        {
            auto x = x0 + i;
            auto y = y0;

            const double p = (double)i / (double)a;
            inv_zi = (1.0 - p) / z0 + p / z1;

            if (inv_zi <= buffer[x][y])
            {
                image(x, y) = color;
                buffer[x][y] = inv_zi;
            }
        }
    }
    else
    {
        // Diagonal line, 3 cases depending on slope
        double m = ((double)y1 - (double)y0) / ((double)x1 - (double)x0);
        if (-1.0 <= m && m <= 1.0)
        {
            const auto a = x1 - x0;

            for (int i = 0; i <= x1 - x0; i++)
            {
                const auto x = x0 + i;
                const auto y = (unsigned int)round(y0 + m * i);

                const double p = (double)i / (double)a;
                inv_zi = (1.0 - p) / z0 + p / z1;

                if (inv_zi <= buffer[x][y])
                {
                    image(x, y) = color;
                    buffer[x][y] = inv_zi;
                }
            }
        }
        else if (m > 1.0)
        {
            const auto a = y1 - y0;

            for (int i = 0; i <= a; i++)
            {
                auto x = (unsigned int)round(x0 + (i / m));
                auto y = y0 + i;

                const double p = (double)i / (double)a;
                inv_zi = (1.0 - p) / z0 + p / z1;

                if (inv_zi <= buffer[x][y])
                {
                    image(x, y) = color;
                    buffer[x][y] = inv_zi;
                }
            }
        }
        else if (m < -1.0)
        {
            const auto a = y0 - y1;
            for (int i = 0; i <= a; i++)
            {
                auto x = (unsigned int)round(x0 - (i / m));
                auto y = y0 - i;

                const double p = (double)i / (double)a;
                // inv_zi = (1.0 - p) / z0 + p / z1;
                inv_zi = (1.0 - p) / z0 + p / z1;

                if (inv_zi <= buffer[x][y])
                {
                    image(x, y) = color;
                    buffer[x][y] = inv_zi;
                }
            }
        }
    }
}


void ZBuffer::draw_zbuf_triag(img::EasyImage& image,
                              const Vector3D& A,
                              const Vector3D& B,
                              const Vector3D& C,
                              double d,
                              double dx,
                              double dy,
                              const Color& ambientReflection,
                              const Color& diffuseReflection,
                              const Color& specularReflection,
                              double reflectionCoefficient,
                              const Lights3D& lights)
{
    Vector3D normal = Vector3D::normalise(Vector3D::cross(B - A, C - A));

    double r = 0, g = 0, b = 0;

    for (const Light& light : lights)
    {
        // Ambient
        r += ambientReflection.red * light.ambientLight.red;
        g += ambientReflection.green * light.ambientLight.green;
        b += ambientReflection.blue * light.ambientLight.blue;

        // Diffuse
        if (light.infinity)
        {
            Vector3D l = Vector3D::normalise(-light.direction);

            double cos_alpha = Vector3D::dot(l, normal);

            if (cos_alpha > 0)
            {
                r += diffuseReflection.red * light.diffuseLight.red * cos_alpha;
                g += diffuseReflection.green * light.diffuseLight.green * cos_alpha;
                b += diffuseReflection.blue * light.diffuseLight.blue * cos_alpha;
            }
        }
        else
        {

            Vector3D triangle_center = (A + B + C) * (1.0 / 3.0);
            Vector3D l = light.location - triangle_center;
            l.normalise();
            double cos_alpha = Vector3D::dot(normal, l);

            if (cos_alpha > 0)
            {
                r += diffuseReflection.red   * light.diffuseLight.red   * cos_alpha;
                g += diffuseReflection.green * light.diffuseLight.green * cos_alpha;
                b += diffuseReflection.blue  * light.diffuseLight.blue  * cos_alpha;
            }

        }
    }

    img::Color final_color(
        std::min(255.0, r * 255.0),
        std::min(255.0, g * 255.0),
        std::min(255.0, b * 255.0)
    );


    // === Project points to 2D
    auto project = [d, dx, dy](const Vector3D& P) -> Point2D
    {
        return Point2D{d * P.x / -P.z + dx, d * P.y / -P.z + dy};
    };

    // Project 3D points to 2D
    Point2D a2d = project(A);
    Point2D b2d = project(B);
    Point2D c2d = project(C);

    // 1/z values
    double inv_zA = 1.0 / A.z;
    double inv_zB = 1.0 / B.z;
    double inv_zC = 1.0 / C.z;

    double xG = (a2d.x + b2d.x + c2d.x) / 3.0;
    double yG = (a2d.y + b2d.y + c2d.y) / 3.0;
    double inv_zG = (inv_zA + inv_zB + inv_zC) / 3.0;

    double det = (b2d.x - a2d.x) * (c2d.y - a2d.y) - (c2d.x - a2d.x) * (b2d.y - a2d.y);
    if (std::abs(det) < 1e-10) return;

    double dzdx = ((inv_zB - inv_zA) * (c2d.y - a2d.y) - (inv_zC - inv_zA) * (b2d.y - a2d.y)) / det;
    double dzdy = ((b2d.x - a2d.x) * (inv_zC - inv_zA) - (c2d.x - a2d.x) * (inv_zB - inv_zA)) / det;

    int y_min = std::round(std::min({a2d.y, b2d.y, c2d.y}));
    int y_max = std::round(std::max({a2d.y, b2d.y, c2d.y}));

    for (int y = y_min; y <= y_max; ++y)
    {
        std::vector<double> xints;
        for (auto [p, q] : {std::pair{a2d, b2d}, {a2d, c2d}, {b2d, c2d}})
        {
            if ((y >= std::min(p.y, q.y)) && (y <= std::max(p.y, q.y)) && p.y != q.y)
            {
                double x = p.x + (y - p.y) * (q.x - p.x) / (q.y - p.y);
                xints.push_back(x);
            }
        }

        if (xints.size() >= 2)
        {
            std::sort(xints.begin(), xints.end());
            int x_start = std::round(xints[0]);
            int x_end = std::round(xints[1]);

            for (int x = x_start; x <= x_end; ++x)
            {
                double inv_z = inv_zG + (x - xG) * dzdx + (y - yG) * dzdy;
                if (x >= 0 && x < image.get_width() && y >= 0 && y < image.get_height())
                {
                    if (buffer[x][y] > inv_z)
                    {
                        buffer[x][y] = inv_z;
                        image(x, y) = final_color;
                    }
                }
            }
        }
    }
}

void ZBuffer::draw_zbuf_triag(img::EasyImage& image, const Vector3D& A, const Vector3D& B, const Vector3D& C, double d,
                              double dx, double dy, const img::Color& normalColor)

{
    auto project = [d, dx, dy](const Vector3D& P) -> Point2D
    {
        return Point2D{
            d * P.x / -P.z + dx,
            d * P.y / -P.z + dy
        };
    };

    Point2D a2d = project(A);
    Point2D b2d = project(B);
    Point2D c2d = project(C);

    // 1/z values
    double inv_zA = 1.0 / A.z;
    double inv_zB = 1.0 / B.z;
    double inv_zC = 1.0 / C.z;

    double xG = (a2d.x + b2d.x + c2d.x) / 3.0;
    double yG = (a2d.y + b2d.y + c2d.y) / 3.0;

    // 1/z at the centroid
    double inv_zG = (inv_zA + inv_zB + inv_zC) / 3.0;

    // Calculate dzdx and dzdy
    double x1 = a2d.x, y1 = a2d.y;
    double x2 = b2d.x, y2 = b2d.y;
    double x3 = c2d.x, y3 = c2d.y;

    double z1 = inv_zA, z2 = inv_zB, z3 = inv_zC;

    double det = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
    if (std::abs(det) < 1e-10) return;

    double dzdx = ((z2 - z1) * (y3 - y1) - (z3 - z1) * (y2 - y1)) / det;
    double dzdy = ((x2 - x1) * (z3 - z1) - (x3 - x1) * (z2 - z1)) / det;

    int y_min = std::round(std::min({a2d.y, b2d.y, c2d.y}) + 0.5);
    int y_max = std::round(std::max({a2d.y, b2d.y, c2d.y}) - 0.5);

    for (int yI = y_min; yI <= y_max; ++yI)
    {
        std::vector<double> x_intersections;

        std::vector<std::pair<Point2D, Point2D>> edges = {
            {a2d, b2d}, {a2d, c2d}, {b2d, c2d}
        };

        for (const auto& [P, Q] : edges)
        {
            if ((yI - P.y) * (yI - Q.y) <= 0 && P.y != Q.y)
            {
                double t = (yI - P.y) / (Q.y - P.y);
                double xI = P.x + t * (Q.x - P.x);
                x_intersections.push_back(xI);
            }
        }

        if (x_intersections.size() >= 2)
        {
            if (x_intersections[0] > x_intersections[1])
                std::swap(x_intersections[0], x_intersections[1]);

            int x_start = std::round(x_intersections[0] + 0.5);
            int x_end = std::round(x_intersections[1] - 0.5);

            for (int x = x_start; x <= x_end; ++x)
            {
                if (x < 0 || x >= image.get_width() || yI < 0 || yI >= image.get_height())
                    continue;

                double inv_z = inv_zG + (x - xG) * dzdx + (yI - yG) * dzdy;

                if (buffer[x][yI] > inv_z)
                {
                    buffer[x][yI] = inv_z;
                    image(x, yI) = normalColor;
                }
            }
        }
    }
}

vector<Face> ZBuffer::triangulate(Face const& face)
{
    vector<Face> result;

    for (int i = 1, n = face.point_indexes.size(); i <= n - 2; i++)
    {
        Face f;
        f.point_indexes = {face.point_indexes[0], face.point_indexes[i], face.point_indexes[i + 1]};
        result.push_back(f);
    }

    return result;
}
