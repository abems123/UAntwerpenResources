//
// Created by Abdellah on 4/14/2025.
//

#ifndef COLOR_H
#define COLOR_H

class Color {
public:
    double red, green, blue;

    Color() = default;

    Color(const double red, const double green, const double blue)
        : red(red),
          green(green),
          blue(blue) {
    }
};

#endif //COLOR_H
