//
// Created by Abdellah on 5/18/2025.
//

#ifndef INFLIGHT_H
#define INFLIGHT_H
#include "Light.h"
#include "vector3d.h"

class InfLight: public Light
{
public:
    //de richting waarin het
    //licht schijnt
    Vector3D ldVector;
};


#endif //INFLIGHT_H
