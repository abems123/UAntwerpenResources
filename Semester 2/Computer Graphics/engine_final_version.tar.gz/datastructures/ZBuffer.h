//
// Created by Abdellah on 5/5/2025.
//

#ifndef ZBUFFER_H
#define ZBUFFER_H
#include <cmath>
#include <limits>
#include <vector>

#include "Light.h"


class Color;
class Face;
class Vector3D;

namespace img
{
    class Color;
    class EasyImage;
}


using namespace std;

class ZBuffer
{
public:
    int width{}, height{};
    std::vector<std::vector<double>> buffer;

    ZBuffer() = default;

    ZBuffer(const int width, const int height)
        : width(width), height(height)
    {
        buffer = std::vector(width, std::vector<double>(height));
    }

    void draw_zbuf_line(img::EasyImage& image, const unsigned int x0, const unsigned int y0,
                        const double z0,
                        unsigned int x1, const unsigned int y1, const double z1, const img::Color& color);

    void draw_zbuf_triag(img::EasyImage& image, const Vector3D& A, const Vector3D& B, const Vector3D& C,
                              double d, double dx, double dy,
                              const Color& ambientReflection, const Color& diffuseReflection,
                              const Color& specularReflection, double reflectionCoeff,
                              const Lights3D& lights);

    void draw_zbuf_triag(img::EasyImage& image, const Vector3D& A, const Vector3D& B, const Vector3D& C,
                         double d, double dx, double dy, const img::Color& normalColor);


    static vector<Face> triangulate(Face const& face);

    [[nodiscard]] int getWidth() const;
    [[nodiscard]] int getHeight() const;

    static bool areEqual(const double a, const double b)
    {
        return fabs(a - b) < 1e-9;
    }
};


#endif //ZBUFFER_H
