//
// Created by Abdellah on 4/14/2025.
//

#ifndef LINE2D_H
#define LINE2D_H

#include <list>

#include "Color.h"
#include "Point2D.h"
#include "../utils/easy_image.h"


class Line2D
{
public:
    Point2D p1{}, p2{};
    img::Color normalColor;
    Color ambientReflection;
    Color diffuseReflection;
    Color specularReflection;
    double reflectionCoefficient{};


    double z1{};
    double z2{};

    Line2D() = default;

    Line2D(const Point2D& p1, const Point2D& p2,
           const img::Color& normalColor)
        : p1(p1),
          p2(p2),
          normalColor(normalColor)
    {
    }

    Line2D(const Point2D& p1, const Point2D& p2, const Color& ambientReflection,
           const Color& diffuseReflection,
           const Color& specularReflection, double reflectionCoefficient, const double z1, const double z2)
        : p1(p1),
          p2(p2),
          ambientReflection(ambientReflection),
          diffuseReflection(diffuseReflection),
          specularReflection(specularReflection),
          reflectionCoefficient(reflectionCoefficient), z1(z1), z2(z2)
    {
    }
};

using Lines2D = std::list<Line2D>;

#endif //LINE2D_H
