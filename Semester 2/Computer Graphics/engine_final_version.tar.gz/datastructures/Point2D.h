//
// Created by Abdellah on 4/14/2025.
//

#ifndef POINT2D_H
#define POINT2D_H

class Point2D {
public:
    double x, y;

    Point2D() = default;

    [[nodiscard]] Point2D(const double x, const double y)
        : x(x),
          y(y) {
    }

    bool operator==(const Point2D& point_2d) const
    {
        return x == point_2d.x && y == point_2d.y;
    }
};

#endif //POINT2D_H
