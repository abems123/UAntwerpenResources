//
// Created by Abdellah on 5/18/2025.
//

#ifndef POINTLIGHT_H
#define POINTLIGHT_H
#include "Light.h"
#include "vector3d.h"

class PointLight : public Light
{
public:
    //de locatie van de puntbron
    Vector3D location;
    //de hoek van een spotlicht
    double spotAngle;
};


#endif //POINTLIGHT_H
