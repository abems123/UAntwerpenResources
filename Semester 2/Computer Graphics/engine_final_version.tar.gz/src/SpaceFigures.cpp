//
// Created by Abdellah on 4/30/2025.
//

#include "../datastructures/Figure.h"


#include "SpaceFigures.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>

#include "Transformations.h"
#include "../datastructures/Point2D.h"
#include "../datastructures/vector3d.h"

Figure SpaceFigures::createTetrahedron()
{
    Figure figure;

    Vector3D p1, p2, p3, p4;
    p1.x = p2.y = p3.x = p3.y = p3.z = p4.z = 1;
    p1.y = p1.z = p2.x = p2.z = p4.x = p4.y = -1;

    Face f1, f2, f3, f4;
    f1.point_indexes = {1, 2, 3};
    f2.point_indexes = {2, 4, 3};
    f3.point_indexes = {1, 4, 2};
    f4.point_indexes = {1, 3, 4};

    figure.faces = {f1, f2, f3, f4};
    figure.points = {p1, p2, p3, p4};

    return figure;
}

Figure SpaceFigures::createCube()
{
    Figure figure;

    Vector3D p1, p2, p3, p4, p5, p6, p7, p8;
    p1.x = p2.y = p3.x = p3.y = p3.z = p4.z = p5.x = p5.y = p7.x = p7.z = p8.y = p8.z = 1;
    p1.y = p1.z = p2.x = p2.z = p4.x = p4.y = p5.z = p6.x = p6.y = p6.z = p7.y = p8.x = -1;



    Face f1, f2, f3, f4, f5, f6;
    f1.point_indexes = {1, 5, 3, 7};
    f2.point_indexes = {5, 2, 8, 3};
    f3.point_indexes = {2, 6, 4, 8};
    f4.point_indexes = {6, 1, 7, 4};
    f5.point_indexes = {7, 3, 8, 4};
    f6.point_indexes = {1, 6, 2, 5};


    figure.faces = {f1, f2, f3, f4, f5, f6};
    figure.points = {p1, p2, p3, p4, p5, p6, p7, p8};
    return figure;
}

Figure SpaceFigures::createIcosahedron()
{
    Figure figure;
    Vector3D p1;
    Vector3D p12;
    p1.x = p1.y = p12.x = p12.y = 0;
    p1.z = sqrt(5) / 2;
    p12.z = -sqrt(5) / 2;

    figure.points.push_back(p1);

    for (int i = 2; i < 7; i++)
    {
        Vector3D p;
        double expressie = (i - 2) * 2 * M_PI / 5;
        p.x = cos(expressie);
        p.y = sin(expressie);
        p.z = 0.5;
        figure.points.push_back(p);
    }

    for (int i = 7; i < 12; i++)
    {
        Vector3D p;
        double expressie = M_PI / 5 + (i - 7) * 2 * M_PI / 5;
        p.x = cos(expressie);
        p.y = sin(expressie);
        p.z = -0.5;
        figure.points.push_back(p);
    }


    Face f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20;
    f1.point_indexes = {1, 2, 3};
    f2.point_indexes = {1, 3, 4};
    f3.point_indexes = {1, 4, 5};
    f4.point_indexes = {1, 5, 6};
    f5.point_indexes = {1, 6, 2};
    f6.point_indexes = {2, 7, 3};
    f7.point_indexes = {3, 7, 8};
    f8.point_indexes = {3, 8, 4};
    f9.point_indexes = {4, 8, 9};
    f10.point_indexes = {4, 9, 5};
    f11.point_indexes = {5, 9, 10};
    f12.point_indexes = {5, 10, 6};
    f13.point_indexes = {6, 10, 11};
    f14.point_indexes = {6, 11, 2};
    f15.point_indexes = {2, 11, 7};
    f16.point_indexes = {12, 8, 7};
    f17.point_indexes = {12, 9, 8};
    f18.point_indexes = {12, 10, 9};
    f19.point_indexes = {12, 11, 10};
    f20.point_indexes = {12, 7, 11};

    figure.points.push_back(p12);
    figure.faces = {f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20};
    return figure;
}

Figure SpaceFigures::createOctahedron()
{
    Figure figure;
    Vector3D p1, p2, p3, p4, p5, p6;
    p1.x = p2.y = p6.z = 1;
    p3.x = p4.y = p5.z = -1;
    p1.y = p1.z = p2.x = p2.z = p3.y = p3.z = p4.x = p4.z = p5.x = p5.y = p6.x = p6.y = 0;

    Face f1, f2, f3, f4, f5, f6, f7, f8;
    f1.point_indexes = {1, 2, 6};
    f2.point_indexes = {2, 3, 6};
    f3.point_indexes = {3, 4, 6};
    f4.point_indexes = {4, 1, 6};
    f5.point_indexes = {2, 1, 5};
    f6.point_indexes = {3, 2, 5};
    f7.point_indexes = {4, 3, 5};
    f8.point_indexes = {1, 4, 5};

    figure.points = {p1, p2, p3, p4, p5, p6};
    figure.faces = {f1, f2, f3, f4, f5, f6, f7, f8};
    return figure;
}

Figure SpaceFigures::createDodecahedron()
{
    Figure figure;

    vector<Vector3D> points(20);
    Figure icosahedron = createIcosahedron();

    for (int i = 0; i < 20; i++)
    {
        auto [point_indexes] = icosahedron.faces[i];

        Vector3D p1 = icosahedron.points[point_indexes[0] - 1];
        Vector3D p2 = icosahedron.points[point_indexes[1] - 1];
        Vector3D p3 = icosahedron.points[point_indexes[2] - 1];

        Vector3D new_point;
        new_point.x = (p1.x + p2.x + p3.x) / 3.0;
        new_point.y = (p1.y + p2.y + p3.y) / 3.0;
        new_point.z = (p1.z + p2.z + p3.z) / 3.0;

        points[i] = new_point;
    }

    Face f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12;
    f1.point_indexes = {1, 2, 3, 4, 5};
    f2.point_indexes = {1, 6, 7, 8, 2};
    f3.point_indexes = {2, 8, 9, 10, 3};
    f4.point_indexes = {3, 10, 11, 12, 4};
    f5.point_indexes = {4, 12, 13, 14, 5};
    f6.point_indexes = {5, 14, 15, 6, 1};
    f7.point_indexes = {20, 19, 18, 17, 16};
    f8.point_indexes = {20, 15, 14, 13, 19};
    f9.point_indexes = {19, 13, 12, 11, 18};
    f10.point_indexes = {18, 11, 10, 9, 17};
    f11.point_indexes = {17, 9, 8, 7, 16};
    f12.point_indexes = {16, 7, 6, 15, 20};

    figure.points = points;
    figure.faces = {f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12};

    return figure;
}

Figure SpaceFigures::createSphere(const int n)
{
    Figure sphere = createIcosahedron();

    for (int i = 0; i < n; i++)
    {
        vector<Face> to_remove_faces;

        for (int j = 0, m = sphere.faces.size(); j < m; j++)
        {
            Face current_face = sphere.faces[j];
            Vector3D a = sphere.points[current_face.point_indexes[0] - 1];
            Vector3D b = sphere.points[current_face.point_indexes[1] - 1];
            Vector3D c = sphere.points[current_face.point_indexes[2] - 1];

            Vector3D e;
            e.x = (a.x + c.x) / 2.0;
            e.y = (a.y + c.y) / 2.0;
            e.z = (a.z + c.z) / 2.0;

            Vector3D d;
            d.x = (a.x + b.x) / 2.0;
            d.y = (a.y + b.y) / 2.0;
            d.z = (a.z + b.z) / 2.0;

            Vector3D f;
            f.x = (b.x + c.x) / 2.0;
            f.y = (b.y + c.y) / 2.0;
            f.z = (b.z + c.z) / 2.0;

            sphere.points.push_back(d);
            sphere.points.push_back(e);
            sphere.points.push_back(f);

            int d_index = static_cast<int>(sphere.points.size() - 2), e_index = static_cast<int>(sphere.points.size()) -
                    1, f_index =
                    static_cast<int>(sphere.points.size());
            Face f1, f2, f3, f4;
            f1.point_indexes = {current_face.point_indexes[0], d_index, e_index};
            f2.point_indexes = {current_face.point_indexes[1], f_index, d_index};
            f3.point_indexes = {current_face.point_indexes[2], e_index, f_index};
            f4.point_indexes = {d_index, f_index, e_index};

            sphere.faces.push_back(f1);
            sphere.faces.push_back(f2);
            sphere.faces.push_back(f3);
            sphere.faces.push_back(f4);

            to_remove_faces.push_back(current_face);
        }
        // Remove all ABC triangle (which are the old big triangle)
        for (const auto& f : to_remove_faces)
            sphere.faces.erase(std::remove(sphere.faces.begin(), sphere.faces.end(), f), sphere.faces.end());
    }
    // Herschalen
    for (auto& p : sphere.points)
    {
        const double r = sqrt(pow(p.x, 2) + pow(p.y, 2) + pow(p.z, 2));

        p.x = p.x / r;
        p.y = p.y / r;
        p.z = p.z / r;
    }


    return sphere;
}

Figure SpaceFigures::createCone(const int n, const double h)
{
    Figure figure;

    vector<Vector3D> points;
    vector<Face> faces;


    for (int i = 0; i < n; i++)
    {
        Vector3D point;
        point.x = cos(2 * i * M_PI / n);
        point.y = sin(2 * i * M_PI / n);
        point.z = 0;
        points.push_back(point);

        Face face;
        face.point_indexes = {
            i + 1, ((i + 1) % n) + 1, n + 1
        };
        faces.push_back(face);
    }
    Vector3D pn;
    pn.x = 0;
    pn.y = 0;
    pn.z = h;

    points.push_back(pn);

    Face fn;
    for (int i = n; i > 0; i--)
        fn.point_indexes.push_back(i);
    faces.push_back(fn);

    figure.points = points;
    figure.faces = faces;

    return figure;
}

Figure SpaceFigures::createCylinder(const int n, const double h)
{
    Figure figure;

    vector<Vector3D> points;
    vector<Face> faces;


    Face vlak;
    // =============== Grondvlak points ===============
    for (int i = 0; i < n; i++)
    {
        Vector3D point;
        point.x = cos(2 * i * M_PI / n);
        point.y = sin(2 * i * M_PI / n);
        point.z = 0;
        points.push_back(point);

        Face face;
        face.point_indexes = {
            i, i + n, (i + 1) % n + n, (i + 1) % n
        };
        faces.push_back(face);
        vlak.point_indexes.push_back(i);
    }
    faces.push_back(vlak);

    // =============== Bovenvlak points ===============
    vlak.point_indexes.clear();
    for (int i = n; i < 2 * n; i++)
    {
        Vector3D point;
        point.x = cos(2 * i * M_PI / n);
        point.y = sin(2 * i * M_PI / n);
        point.z = h;
        points.push_back(point);

        vlak.point_indexes.push_back(i);
    }
    faces.push_back(vlak);


    for (auto& [point_indexes] : faces)
        for (auto& i : point_indexes)
            i++;

    figure.points = points;
    figure.faces = faces;

    return figure;
}

Figure SpaceFigures::createTorus(double r, double R, const int n, const int m)
{
    Figure figure;

    map<int, map<int, int>> points;
    vector<vector<Face>> faces;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            double u = 2 * M_PI * i / n;
            double v = 2 * M_PI * j / m;

            double xuv = (R + r * cos(v)) * cos(u);
            double yuv = (R + r * cos(v)) * sin(u);
            double zuv = r * sin(v);

            Vector3D pij;
            pij.x = xuv;
            pij.y = yuv;
            pij.z = zuv;
            figure.points.push_back(pij);
            points[i][j] = figure.points.size() - 1;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            Face fij;
            fij.point_indexes = {
                points[i][j], points[(i + 1) % n][j], points[(i + 1) % n][(j + 1) % m], points[i][(j + 1) % m]
            };
            figure.faces.push_back(fij);
        }
    }

    for (auto& [point_indexes] : figure.faces)
        for (auto& p : point_indexes)
            p++;
    return figure;
}
Figure SpaceFigures::createBuckyBall()
{
    Figure bucky= createIcosahedron();

    return bucky;
}




Figure SpaceFigures::createFigure(string name, int n, double h, double r, double R, int m, int i)
{
    if (name == "Cube")
        return createCube();
    if (name == "Tetrahedron")
        return createTetrahedron();
    if (name == "Icosahedron")
        return createIcosahedron();
    if (name == "Octahedron")
        return createOctahedron();
    if (name == "Dodecahedron")
        return createDodecahedron();
    if (name == "Cone")
        return createCone(n, h);
    if (name == "Sphere")
        return createSphere(n);
    if (name == "Cylinder")
        return createCylinder(n, h);
    if (name == "Torus")
        return createTorus(r, R, n, m);
    if (name == "BuckyBall")
        return createBuckyBall();
    if (name == "MengerSponge")
        return createMengerSponge(i);
    return Figure();
}

void generateFractalHelper(const Figure& base, Figures3D& result, int iteration, int max_iterations, double scale)
{
    if (iteration >= max_iterations)
    {
        result.push_back(base);
        return;
    }

    for (size_t k = 0; k < base.points.size(); ++k)
    {
        Figure small = base;
        Transformations::applyTransformation(small, Transformations::scaleFigure(1.0 / scale));

        // Align j-th point of small shape with same j-th point of big shape
        Vector3D match = small.points[k];
        Vector3D target = base.points[k];
        Transformations::applyTransformation(small, Transformations::translate(target.x - match.x, target.y - match.y, target.z - match.z));

        generateFractalHelper(small, result, iteration + 1, max_iterations, scale);
    }
}

void SpaceFigures::generateFractal(const Figure& base, Figures3D& result, const int nr_iterations, const double scale)
{
    if (nr_iterations == 0)
    {
        result.push_back(base);
        return;
    }
    generateFractalHelper(base, result, 0, nr_iterations, scale);
}


static void generateMengerRecursive(const Vector3D& center, double size, int step, Figures3D& result)
{
    if (step == 0)
    {
        Figure cube = SpaceFigures::createCube();
        Transformations::applyTransformation(cube, Transformations::scaleFigure(size / 2.0));
        Transformations::applyTransformation(cube, Transformations::translate(center.x, center.y, center.z));
        result.push_back(cube);
        return;
    }

    double newSize = size / 3.0;

    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                // Skip the center cube and center face cubes
                if ((i == 1 && j == 1) || (j == 1 && k == 1) || (i == 1 && k == 1))
                    continue;

                Vector3D new_center;
                new_center.x = center.x + (i - 1) * newSize;
                new_center.y = center.y + (j - 1) * newSize;
                new_center.z = center.z + (k - 1) * newSize;

                generateMengerRecursive(new_center, newSize, step - 1, result);
            }
        }
    }
}


Figure SpaceFigures::createMengerSponge(int iterations)
{
    Figures3D cubes;
    Vector3D origin;
    origin.x = origin.y = origin.z = 0;

    generateMengerRecursive(origin, 1.0, iterations, cubes);

    // Merge all cubes into one figure
    Figure sponge;
    int pointOffset = 0;

    for (const Figure& cube : cubes)
    {
        for (const Vector3D& p : cube.points)
            sponge.points.push_back(p);

        for (const Face& f : cube.faces)
        {
            Face newF = f;
            for (int& i : newF.point_indexes)
                i += pointOffset;
            sponge.faces.push_back(newF);
        }

        pointOffset += cube.points.size();
    }

    return sponge;
}
