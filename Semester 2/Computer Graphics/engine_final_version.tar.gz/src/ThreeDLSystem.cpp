//
// Created by Abdellah on 5/3/2025.
//

#include "ThreeDLSystem.h"

#include <cmath>
#include <stack>

#include "TwoDOperations.h"
#include "../datastructures/vector3d.h"

// This is a struct of the turtle
struct Turtle3D
{
    Vector3D position;
    Vector3D H;
    Vector3D L;
    Vector3D U;
};

// This method returns the next version the txt after one iteration of replacing each letter with the corresponding string
string ThreeDLSystem::get_next_version(string& txt, const LParser::LSystem3D& ls)
{
    string result;

    for (const char& c : txt)
    {
        bool alpha = false;
        for (auto& a : ls.get_alphabet())
        {
            if (a == c)
                alpha = true;
        }

        if (!alpha)
            result += c;
        else
            result += ls.get_replacement(c);
    }
    return result;
}

// This method helps me to get the index of a point in a vector of points
int ThreeDLSystem::getPointIndex(const Vector3D& point, const vector<Vector3D>& points)
{
    int result = 1;
    for (const auto& p : points)
    {
        if (p.x == point.x && p.y == point.y && p.z == point.z)
            break;

        result++;
    }

    return result;
}

Figure ThreeDLSystem::draw3DLSystem(const LParser::LSystem3D& l_system)
{
    const auto iterations = l_system.get_nr_iterations();
    string l_system_text = l_system.get_initiator();
    double angle = l_system.get_angle() * M_PI / 180;

    // Generating the last version of our lsystem
    for (int i = 0; i < iterations; i++)
        l_system_text = get_next_version(l_system_text, l_system);

    // Making the H, L and U vectors
    Vector3D H;
    H.x = 1;
    H.y = H.z = 0;
    Vector3D L;
    L.y = 1;
    L.x = L.z = 0;
    Vector3D U;
    U.z = 1;
    U.x = U.y = 0;


    // This is the turtle
    Turtle3D turtle_3d;
    turtle_3d.position.x = turtle_3d.position.y = turtle_3d.position.z = 0;
    turtle_3d.H = H;
    turtle_3d.L = L;
    turtle_3d.U = U;

    vector<Vector3D> points;
    vector<Face> faces;

    stack<Turtle3D> stack;

    for (const auto c : l_system_text)
    {
        if (c == '+')
        {
            Vector3D new_H;
            Vector3D new_L;

            new_H.x = H.x * cos(angle) + L.x * sin(angle);
            new_H.y = H.y * cos(angle) + L.y * sin(angle);
            new_H.z = H.z * cos(angle) + L.z * sin(angle);

            new_L.x = -H.x * sin(angle) + L.x * cos(angle);
            new_L.y = -H.y * sin(angle) + L.y * cos(angle);
            new_L.z = -H.z * sin(angle) + L.z * cos(angle);

            H = new_H;
            L = new_L;
        }
        else if (c == '-')
        {
            Vector3D new_H;
            Vector3D new_L;

            new_H.x = H.x * cos(-angle) + L.x * sin(-angle);
            new_H.y = H.y * cos(-angle) + L.y * sin(-angle);
            new_H.z = H.z * cos(-angle) + L.z * sin(-angle);

            new_L.x = -H.x * sin(-angle) + L.x * cos(-angle);
            new_L.y = -H.y * sin(-angle) + L.y * cos(-angle);
            new_L.z = -H.z * sin(-angle) + L.z * cos(-angle);

            H = new_H;
            L = new_L;
        }
        else if (c == '^')
        {
            Vector3D new_H;
            Vector3D new_U;

            new_H.x = H.x * cos(angle) + U.x * sin(angle);
            new_H.y = H.y * cos(angle) + U.y * sin(angle);
            new_H.z = H.z * cos(angle) + U.z * sin(angle);

            new_U.x = -H.x * sin(angle) + U.x * cos(angle);
            new_U.y = -H.y * sin(angle) + U.y * cos(angle);
            new_U.z = -H.z * sin(angle) + U.z * cos(angle);

            H = new_H;
            U = new_U;
        }
        else if (c == '&')
        {
            Vector3D new_H;
            Vector3D new_U;

            new_H.x = H.x * cos(-angle) + U.x * sin(-angle);
            new_H.y = H.y * cos(-angle) + U.y * sin(-angle);
            new_H.z = H.z * cos(-angle) + U.z * sin(-angle);

            new_U.x = -H.x * sin(-angle) + U.x * cos(-angle);
            new_U.y = -H.y * sin(-angle) + U.y * cos(-angle);
            new_U.z = -H.z * sin(-angle) + U.z * cos(-angle);

            H = new_H;
            U = new_U;
        }
        else if (c == '\\')
        {
            Vector3D new_L;
            Vector3D new_U;

            new_L.x = L.x * cos(angle) - U.x * sin(angle);
            new_L.y = L.y * cos(angle) - U.y * sin(angle);
            new_L.z = L.z * cos(angle) - U.z * sin(angle);

            new_U.x = L.x * sin(angle) + U.x * cos(angle);
            new_U.y = L.y * sin(angle) + U.y * cos(angle);
            new_U.z = L.z * sin(angle) + U.z * cos(angle);

            L = new_L;
            U = new_U;
        }
        else if (c == '/')
        {
            Vector3D new_L;
            Vector3D new_U;

            new_L.x = L.x * cos(-angle) - U.x * sin(-angle);
            new_L.y = L.y * cos(-angle) - U.y * sin(-angle);
            new_L.z = L.z * cos(-angle) - U.z * sin(-angle);

            new_U.x = L.x * sin(-angle) + U.x * cos(-angle);
            new_U.y = L.y * sin(-angle) + U.y * cos(-angle);
            new_U.z = L.z * sin(-angle) + U.z * cos(-angle);

            L = new_L;
            U = new_U;
        }
        else if (c == '|')
        {
            H.x = -H.x;
            H.y = -H.y;
            H.z = -H.z;

            L.x = -L.x;
            L.y = -L.y;
            L.z = -L.z;
        }
        else if (c == '(')
        {
            stack.push(turtle_3d);
            continue;
        }
        else if (c == ')')
        {
            if (!stack.empty())
            {
                turtle_3d = stack.top();
                H = turtle_3d.H;
                U = turtle_3d.U;
                L = turtle_3d.L;
                stack.pop();
                continue;
            }
        }
        else
        {
            if (l_system.draw(c))
            {
                Vector3D new_position = turtle_3d.position + turtle_3d.H;

                points.push_back(turtle_3d.position);
                points.push_back(new_position);

                int current_point = getPointIndex(turtle_3d.position, points);

                Face f;
                f.point_indexes = {current_point, points.size()};
                faces.push_back(f);

                turtle_3d.position = new_position;
            }
        }
        turtle_3d.H = H;
        turtle_3d.L = L;
        turtle_3d.U = U;
    }

    Figure figure;
    figure.points = points;
    figure.faces = faces;

    return figure;
}
