//
// Created by Abdellah on 4/30/2025.
//

#ifndef SPACEFIGURES_H
#define SPACEFIGURES_H
#include <string>


class Figure;

class SpaceFigures
{
public:
    static Figure createTetrahedron();

    static Figure createCube();

    static Figure createIcosahedron();

    static Figure createOctahedron();

    static Figure createDodecahedron();

    static Figure createSphere(int n);

    static Figure createCone(int n, double h);

    static Figure createCylinder(int n, double h);

    static Figure createTorus(double r, double R, int n, int m);

    static Figure createBuckyBall();

    static Figure createFigure(string name, int n=0, double h=0, double r=0, double R=0, int m=0, int i = 0);

   static void generateFractal(const Figure& base, Figures3D& result, const int nr_iterations, const double scale);

    static Figure createMengerSponge(int iterations);

};


#endif //SPACEFIGURES_H
