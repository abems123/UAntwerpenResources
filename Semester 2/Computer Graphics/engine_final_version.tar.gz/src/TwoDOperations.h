//
// Created by AbEms on 3/8/2025.
//


#ifndef LSYSTEMOPERATIONS_H
#define LSYSTEMOPERATIONS_H

#include <string>
#include "../datastructures/Line2D.h"
#include "../datastructures/Color.h"
#include "../lparser/l_parser.h"
#include "../utils/easy_image.h"
#include "../datastructures/Figure.h"
#include "../datastructures/Light.h"

class ZBuffer;
using namespace std;

static const double EPSILON = 1e-9; // Small threshold (0.000000001)
class TwoDOperations
{
public:
    static img::EasyImage draw2DLines(Lines2D lines, int size, const Color& bgcolor, bool zbuffering, const Lights3D& lights);

    static img::EasyImage draw2DLines(Lines2D lines, const int size, const Color& bgcolor, const bool zbuffering, string type = "2DLSystem");


    static Lines2D draw2DLSystem(const LParser::LSystem2D& l_system, Color linesColor);

    static string get_next_version(string& txt, const LParser::LSystem2D& ls);

    // This function is used to compare the double because == doesn't work
    static bool areEqual(const double a, const double b);
};


#endif //LSYSTEMOPERATIONS_H
