//
// Created by AbEms on 3/20/2025.
//

#include "Transformations.h"

#include <cmath>

#include "../datastructures/Point2D.h"
#include "../datastructures/Line2D.h"


Matrix Transformations::scaleFigure(const double scale)
{
    Matrix s;
    s(1, 1) = scale;
    s(2, 2) = scale;
    s(3, 3) = scale;
    return s;
}

Matrix Transformations::rotateX(const double angle)
{
    Matrix mx;
    mx(2, 2) = mx(3, 3) = cos(angle);
    mx(2, 3) = sin(angle);
    mx(3, 2) = -sin(angle);
    return mx;
}

Matrix Transformations::rotateY(const double angle)
{
    Matrix my;
    my(1, 1) = my(3, 3) = cos(angle);
    my(1, 3) = -sin(angle);
    my(3, 1) = sin(angle);
    return my;
}

Matrix Transformations::rotateZ(const double angle)
{
    Matrix mz;
    mz(1, 1) = mz(2, 2) = cos(angle);
    mz(1, 2) = sin(angle);
    mz(2, 1) = -sin(angle);
    return mz;
}

Matrix Transformations::translate(const double d_1, const double d_2, const double d_3)
{
    Matrix t;
    t(4, 1) = d_1;
    t(4, 2) = d_2;
    t(4, 3) = d_3;
    return t;
}

Matrix Transformations::translate(const Vector3D& vector)
{
    Matrix t;
    t(4, 1) = vector.x;
    t(4, 2) = vector.y;
    t(4, 3) = vector.z;
    return t;
}

void Transformations::applyTransformation(Figure& fig, const Matrix& m)
{
    for (auto& p : fig.points)
        p *= m;
}

Matrix Transformations::eyePointTrans(const Vector3D& eyepoint)
{
    auto [r, theta, phi] = toPolar(eyepoint);

    Matrix v = rotateZ(-(theta + M_PI / 2)) * rotateX(-phi) * translate(0, 0, -r);
    return v;
}


void Transformations::applyTransformation(Figures3D& figs, const Matrix& m)
{
    for (auto& fig : figs)
        applyTransformation(fig, m);
}


tuple<double, double, double> Transformations::toPolar(const Vector3D& point)
{
    double theta = atan2(point.y, point.x);
    double r = sqrt(point.x * point.x + point.y * point.y + point.z * point.z);
    double phi = acos(point.z / r);


    return make_tuple(r, theta, phi);
}

Lines2D Transformations::doProjection(const Figures3D& figs)
{
    Lines2D lines;

    for (const auto& fig : figs)
    {
        for (const auto& face : fig.faces)
        {
            for (size_t i = 0; i < face.point_indexes.size(); i++)
            {
                int p1 = face.point_indexes[i];
                int p2 = (i + 1 == face.point_indexes.size()) ? face.point_indexes.front() : face.point_indexes[i + 1];

                Line2D line{};
                line.p1 = doProjection(fig.points[p1 - 1], 1);
                line.p2 = doProjection(fig.points[p2 - 1], 1);
                line.z1 = fig.points[p1 - 1].z;
                line.z2 = fig.points[p2 - 1].z;

                // Set new fields:
                line.normalColor = fig.normalColor;
                line.ambientReflection = fig.ambientReflection;
                line.diffuseReflection = fig.diffuseReflection;
                line.specularReflection = fig.specularReflection;
                line.reflectionCoefficient = fig.reflectionCoefficient;

                lines.push_back(line);
            }
        }
    }
    return lines;
}


Point2D Transformations::doProjection(const Vector3D& point, const double d)
{
    // double z = point.z;
    // if (z == 0) z = 1e-5;
    return Point2D(d * point.x / -point.z, d * point.y / -point.z);
}
