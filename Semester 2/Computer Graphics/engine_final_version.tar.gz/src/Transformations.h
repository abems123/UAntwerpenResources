//
// Created by Abdellah on 4/17/2025.
//

#ifndef TRANSFORMATIONS_H
#define TRANSFORMATIONS_H

#include "../datastructures/vector3d.h"
#include "../datastructures/Figure.h"

class Point2D;
class Line2D;

class Transformations {
public:
    static Matrix scaleFigure(double scale);
    static Matrix rotateX(double angle);
    static Matrix rotateY(double angle);
    static Matrix rotateZ(double angle);
    static Matrix translate(const Vector3D &vector);
    static Matrix translate(double d_1, double d_2, double d_3);

    static void applyTransformation(Figure& fig, const Matrix& m);

    static Matrix eyePointTrans(const Vector3D &eyepoint);

    static void applyTransformation(Figures3D &figs, const Matrix &m);

    static tuple<double, double, double> toPolar(const Vector3D& point);


    static list<Line2D> doProjection(const Figures3D& figs);
    static auto doProjection(const Vector3D& point, double d) -> Point2D;
};



#endif //TRANSFORMATIONS_H
