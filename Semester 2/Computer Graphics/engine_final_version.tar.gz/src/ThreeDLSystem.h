//
// Created by Abdellah on 5/3/2025.
//

#ifndef THREEDLSYSTEM_H
#define THREEDLSYSTEM_H


#include "../datastructures/Figure.h"
#include "../lparser/l_parser.h"
#include "../datastructures/vector3d.h"


using namespace std;

class ThreeDLSystem
{
public:
    static int getPointIndex(const Vector3D& point, const vector<Vector3D>& points);
    static Figure draw3DLSystem(const LParser::LSystem3D& l_system);
    static string get_next_version(string& txt, const LParser::LSystem3D& ls);
};


#endif //THREEDLSYSTEM_H
