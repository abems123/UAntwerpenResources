//
// Created by AbEms on 3/8/2025.
//

#include "TwoDOperations.h"

#include <cmath>
#include <algorithm>
#include <stack>

#include "../datastructures/vector3d.h"
#include "../datastructures/ZBuffer.h"
#include "../utils/ini_configuration.h"

img::EasyImage TwoDOperations::draw2DLines(Lines2D lines, const int size, const Color& bgcolor, const bool zbuffering,
                                           const Lights3D& lights)
{
    ZBuffer zbuffer;

    // Giving each variable a start value that is either the largest possible value or the smallest possible one
    double xmin = numeric_limits<double>::max();
    double xmax = numeric_limits<double>::lowest();
    double ymin = numeric_limits<double>::max();
    double ymax = numeric_limits<double>::lowest();

    // Finding the real of each variable in the lines
    for (auto& line : lines)
    {
        xmin = min({xmin, line.p1.x, line.p2.x});
        xmax = max({xmax, line.p1.x, line.p2.x});
        ymin = min({ymin, line.p1.y, line.p2.y});
        ymax = max({ymax, line.p1.y, line.p2.y});
    }

    const double xrange = !areEqual(xmax, xmin) ? xmax - xmin : xmax;
    const double yrange = !areEqual(ymax, ymin) ? ymax - ymin : ymax;

    // De grootte van de Image berekenen
    double dominator_x = xrange > yrange ? 1 : (xrange / yrange);
    double dominator_y = xrange > yrange ? (yrange / xrange) : 1;

    int imagex = round(size * dominator_x);
    int imagey = round(size * dominator_y);


    img::EasyImage image(imagex, imagey);
    if (zbuffering)
        zbuffer = ZBuffer(imagex, imagey);

    // Coloring the background
    for (int y = 0; y < imagey; y++)
    {
        for (int x = 0; x < imagex; x++)
        {
            image(x, y).red = bgcolor.red * 255;
            image(x, y).green = bgcolor.green * 255;
            image(x, y).blue = bgcolor.blue * 255;
        }
    }

    // De lijntekening schalen
    const double d = 0.95 * imagex / xrange;

    // De coordinaten van alle punten vermenigvuldigen met d
    for (auto& line : lines)
    {
        line.p1.x *= d;
        line.p1.y *= d;
        line.p2.x *= d;
        line.p2.y *= d;
    }

    // De lijtekening verschuiven
    // 1. Berekenen
    const double dcx = d * ((xmin + xmax) / 2.0);
    const double dcy = d * ((ymin + ymax) / 2.0);
    const double dx = imagex / 2.0 - dcx;
    const double dy = imagey / 2.0 - dcy;

    // 2. (dx, dy) optellen bij alle punten
    for (auto& line : lines)
    {
        line.p1.x += dx;
        line.p2.x += dx;
        line.p1.y += dy;
        line.p2.y += dy;
    }


    // De lijnen tekenen op de image
    for (const auto& line : lines)
    {
        ini::DoubleTuple finalColor{0, 0, 0};

        for (const auto& light : lights)
        {
            finalColor[0] += light.ambientLight.red * line.ambientReflection.red / 255;
            finalColor[1] += light.ambientLight.green * line.ambientReflection.green / 255;
            finalColor[2] += light.ambientLight.blue * line.ambientReflection.blue / 255;
        }

        // Clamp to [0, 1]
        finalColor[0] = std::min(255.0, finalColor[0]);
        finalColor[1] = std::min(255.0, finalColor[1]);
        finalColor[2] = std::min(255.0, finalColor[2]);

        // Convert to 0-255 image color
        const img::Color c(finalColor[0], finalColor[1], finalColor[2]);

        // De cordinaten van de punten afronden
        const int xa = round(line.p1.x);
        const int xb = round(line.p2.x);
        const int ya = round(line.p1.y);
        const int yb = round(line.p2.y);

        if (zbuffering)
            zbuffer.draw_zbuf_line(image, xa, ya, line.z1, xb, yb, line.z2, c);
        else
            image.draw_line(xa, ya, xb, yb, c);
    }
    return image;
}


img::EasyImage TwoDOperations::draw2DLines(Lines2D lines, const int size, const Color& bgcolor, const bool zbuffering, string type)
{
    ZBuffer zbuffer;

    // Giving each variable a start value that is either the largest possible value or the smallest possible one
    double xmin = numeric_limits<double>::max();
    double xmax = numeric_limits<double>::lowest();
    double ymin = numeric_limits<double>::max();
    double ymax = numeric_limits<double>::lowest();

    // Finding the real of each variable in the lines
    for (auto& line : lines)
    {
        xmin = min({xmin, line.p1.x, line.p2.x});
        xmax = max({xmax, line.p1.x, line.p2.x});
        ymin = min({ymin, line.p1.y, line.p2.y});
        ymax = max({ymax, line.p1.y, line.p2.y});
    }

    const double xrange = !areEqual(xmax, xmin) ? xmax - xmin : xmax;
    const double yrange = !areEqual(ymax, ymin) ? ymax - ymin : ymax;

    // De grootte van de Image berekenen
    double dominator_x = xrange > yrange ? 1 : (xrange / yrange);
    double dominator_y = xrange > yrange ? (yrange / xrange) : 1;

    int imagex = floor(size * dominator_x);
    int imagey = floor(size * dominator_y);

    if (type == "2DLSystem")
    {
        imagex = floor(size * dominator_x);
        imagey = floor(size * dominator_y);
    }
    else if (type == "Wireframe")
    {
        imagex = round(size * dominator_x);
        imagey = round(size * dominator_y);

    }



    img::EasyImage image(imagex, imagey);
    if (zbuffering)
        zbuffer = ZBuffer(imagex, imagey);

    // Coloring the background
    for (int y = 0; y < imagey; y++)
    {
        for (int x = 0; x < imagex; x++)
        {
            image(x, y).red = bgcolor.red * 255;
            image(x, y).green = bgcolor.green * 255;
            image(x, y).blue = bgcolor.blue * 255;
        }
    }

    // De lijntekening schalen
    const double d = 0.95 * imagex / xrange;

    // De coordinaten van alle punten vermenigvuldigen met d
    for (auto& line : lines)
    {
        line.p1.x *= d;
        line.p1.y *= d;
        line.p2.x *= d;
        line.p2.y *= d;
    }

    // De lijtekening verschuiven
    // 1. Berekenen
    const double dcx = d * ((xmin + xmax) / 2.0);
    const double dcy = d * ((ymin + ymax) / 2.0);
    const double dx = imagex / 2.0 - dcx;
    const double dy = imagey / 2.0 - dcy;

    // 2. (dx, dy) optellen bij alle punten
    for (auto& line : lines)
    {
        line.p1.x += dx;
        line.p2.x += dx;
        line.p1.y += dy;
        line.p2.y += dy;
    }


    // De lijnen tekenen op de image
    for (const auto& line : lines)
    {
        // De cordinaten van de punten afronden
        const int xa = round(line.p1.x);
        const int xb = round(line.p2.x);
        const int ya = round(line.p1.y);
        const int yb = round(line.p2.y);

        const img::Color c(line.normalColor.red, line.normalColor.green, line.normalColor.blue);

        if (zbuffering) zbuffer.draw_zbuf_line(image, xa, ya, line.z1, xb, yb, line.z2, c);
        else image.draw_line(xa, ya, xb, yb, c);
    }
    return image;
}

Lines2D TwoDOperations::draw2DLSystem(const LParser::LSystem2D& l_system, Color linesColor)
{
    const int iterations = l_system.get_nr_iterations();
    string l_system_text = l_system.get_initiator();


    Lines2D lines;

    // Generating the last version of our lsystem
    for (int i = 0; i < iterations; i++)
    {
        l_system_text = get_next_version(l_system_text, l_system);
    }


    int angle = l_system.get_starting_angle();
    const int delta = l_system.get_angle();

    double dx = cos(angle * M_PI / 180.0), dy = sin(angle * M_PI / 180.0); // Direction vector
    double x = 0, y = 0;

    struct State
    {
        Point2D point;
        double dx, dy;
        int angle;

        State(const Point2D& p, const double dx, const double dy, const int angle)
            : point(p), dx(dx), dy(dy), angle(angle)
        {
        }
    };

    stack<State> stateStack;

    for (const char& c : l_system_text)
    {
        if (c == '(')
        {
            // Push the current state onto the stack
            stateStack.push(State(Point2D(x, y), dx, dy, angle));
            continue;
        }
        if (c == ')')
        {
            // Pop the state from the stack and restore it
            if (!stateStack.empty())
            {
                State state = stateStack.top();
                x = state.point.x;
                y = state.point.y;
                dx = state.dx;
                dy = state.dy;
                angle = state.angle;
                stateStack.pop();
            }
            continue;
        }
        if (c == '+')
        {
            angle += delta;
            dx = cos(angle * M_PI / 180.0);
            dy = sin(angle * M_PI / 180.0);
            continue;
        }
        if (c == '-')
        {
            angle -= delta;
            dx = cos(angle * M_PI / 180.0);
            dy = sin(angle * M_PI / 180.0);
            continue;
        }

        if (l_system.draw(c))
        {
            double newX = x + dx;
            double newY = y + dy;

            Point2D p1(x, y);
            Point2D p2(newX, newY);

            lines.emplace_back(p1, p2, img::Color(linesColor.red, linesColor.green, linesColor.blue));

            x = newX;
            y = newY;
        }
    }

    return lines;
}


string TwoDOperations::get_next_version(string& txt, const LParser::LSystem2D& ls)
{
    string result;

    for (const char& c : txt)
    {
        bool alpha = false;
        for (auto& a : ls.get_alphabet())
        {
            if (a == c)
                alpha = true;
        }

        if (!alpha)
            result += c;
        else
            result += ls.get_replacement(c);
    }
    return result;
}


bool TwoDOperations::areEqual(const double a, const double b)
{
    return fabs(a - b) < EPSILON;
}
